﻿Public Class clsErrorLogs
    Inherits clsBase

#Region "Definitions"
    Private oMatrix As SAPbouiCOM.Matrix
    Private oDS As SAPbouiCOM.DBDataSource
    Private oCon As SAPbouiCOM.Condition
    Private oCons As SAPbouiCOM.Conditions
    Private Qrystr, Status, item, WHouse, ApprQty, Indent, docnum As String
    Private i, k As Integer
    Private ors, orec As SAPbobsCOM.Recordset
    Private oDTable As DataTable
    Private oRow As DataRow
    Dim oGrid As SAPbouiCOM.Grid
#End Region

#Region "Item Event"
    Public Overrides Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Select Case pVal.Before_Action
            Case True
                Select Case pVal.EventType
                    Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                        Select Case pVal.ItemUID
                            Case "Ok"
                                oForm.Close()

                        End Select

                    Case SAPbouiCOM.BoEventTypes.et_FORM_CLOSE
                        Me._Object = oApplication.Collection.Item(oApplication.LookUpCollection.Item(_FormUID))
                        _Object.IsLookUpOpen = False


                End Select
            Case False
                Select Case pVal.EventType

                End Select


        End Select
    End Sub
#End Region

#Region "FillForm"
    Public Sub FillForm(ByVal sql As String)
        Try
            oForm.Freeze(True)
            oForm.Items.Item("4").Enabled = False
            oGrid = oForm.Items.Item("4").Specific

            oGrid.DataTable.ExecuteQuery(sql)
            CType(oGrid.Columns.Item("DocEntry"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 46

            'oGrid.DataTable.Clear()
            'Dim DT As SAPbouiCOM.DataTable
            'DT = oForm.DataSources.DataTables.Item(0)
            'DT.Columns.Add("Key", SAPbouiCOM.BoFieldsType.ft_AlphaNumeric, 10)
            'DT.Columns.Add("Error Message", SAPbouiCOM.BoFieldsType.ft_AlphaNumeric, 254)
            'For i = 0 To oDT.Rows.Count - 1
            '    DT.Rows.Add(1)
            '    If IsDBNull(oDT.Rows(i).Item("Key")) = False Then
            '        DT.SetValue(0, i, oDT.Rows(i).Item("Key"))
            '    End If

            '    If IsDBNull(oDT.Rows(i).Item("Error Message")) = False Then
            '        DT.SetValue(1, i, oDT.Rows(i).Item("Error Message"))
            '    End If
            'Next
            'oGrid.Columns.Item("Recreate").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
            oForm.Items.Item("4").Enabled = False
            oGrid.AutoResizeColumns()
            oForm.Freeze(False)
        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        Finally
            oForm.Freeze(False)
        End Try
    End Sub
#End Region

End Class
