﻿
Imports System.Threading
Public Class clsBankExtract
    Inherits clsBase

#Region "Definitions"
    Dim oMatrix As SAPbouiCOM.Matrix
    Dim DocNum, Series, i As Integer
    Dim RS, oRS As SAPbobsCOM.Recordset
    Dim QRY, output, archive, newview, histview, validview, extSP, ProcId, ext, filename, BankAct As String
    Private oDS, oDS1 As SAPbouiCOM.DBDataSource
    Dim oGrid1, oGrid2 As SAPbouiCOM.Grid
    Dim oCombo As SAPbouiCOM.ComboBox
    Public sw As System.IO.TextWriter
    Dim oProgressBar As SAPbouiCOM.ProgressBar

    Private objDialogBox As System.Windows.Forms.FolderBrowserDialog
    Private objProcess() As System.Diagnostics.Process
    Private intLoop As Integer
    Private MyWindow As WindowWrapper
    Dim FolderPath As String = ""
    Private oCFLEvent As SAPbouiCOM.ChooseFromListEvent
#End Region

#Region "MenuEvent"
    Public Overrides Sub MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean)
        Select Case pVal.MenuUID
            Case "BankExtract"
                Try

                    'Dim arInvoicePO As SAPbobsCOM.Documents = CType(oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders), SAPbobsCOM.Documents)
                    'arInvoicePO.GetByKey(7484)
                    'arInvoicePO.Lines.Add()
                    'arInvoicePO.Lines.ItemCode = "F05"
                    'arInvoicePO.Lines.Quantity = 1
                    'Dim ret As Integer = arInvoicePO.Update()


                    oForm.Freeze(True)
                    oGrid1 = oForm.Items.Item("3").Specific
                    oGrid2 = oForm.Items.Item("5").Specific
                    ProcId = Date.Now.ToString("yyyyMMddhhmmss") 'oApplication.Utilities.getMaxCode("@BOSBELOG", "Code", True)
                    'oForm.Items.Item("20").Specific.value = ProcId
                    strSQL = "SELECT Code,Name,U_ACTIVE,U_OUTDIR,U_ARCHDIR,U_FILENAME,U_EXT,U_NEWVIEW,U_HISTVIEW,U_EXTLOGIC,U_VALIDVIEW FROM [@BOSBECONFIG] WHERE U_ACTIVE='Y' "
                    oApplication.Utilities.ExecuteSQL(oRS, strSQL)
                    oCombo = oForm.Items.Item("15").Specific
                    If oRS.RecordCount > 0 Then
                        output = oRS.Fields.Item(3).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                        filename = oRS.Fields.Item(5).Value
                        ext = oRS.Fields.Item(6).Value
                        archive = oRS.Fields.Item(4).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                        newview = oRS.Fields.Item(7).Value
                        histview = oRS.Fields.Item(8).Value
                        extSP = oRS.Fields.Item(9).Value
                        validview = oRS.Fields.Item(10).Value
                        oForm.Items.Item("22").Specific.value = output 'oRS.Fields.Item(3).Value
                        oForm.Items.Item("16").Specific.value = oRS.Fields.Item(1).Value
                        For i = 1 To oRS.RecordCount
                            oCombo.ValidValues.Add(oRS.Fields.Item(0).Value, oRS.Fields.Item(1).Value)
                            oRS.MoveNext()
                        Next
                        oCombo.Select(0, SAPbouiCOM.BoSearchKey.psk_Index)
                    End If
                    oCombo = oForm.Items.Item("23").Specific
                    oCombo.ValidValues.Add("All", "All")
                    oCombo.ValidValues.Add("Due Date", "Due Date")
                    oCombo.ValidValues.Add("Vendor", "Vendor")
                    oCombo.ValidValues.Add("Bank Code", "Bank Code")
                    oCombo.Select("All", SAPbouiCOM.BoSearchKey.psk_ByValue)

                    oCombo = oForm.Items.Item("24").Specific
                    oCombo.ValidValues.Add("All", "All")
                    oCombo.ValidValues.Add("Process ID", "Process ID")
                    oCombo.ValidValues.Add("Vendor", "Vendor")
                    oCombo.ValidValues.Add("Bank Code", "Bank Code")
                    oCombo.ValidValues.Add("Due Date", "Due Date")
                    oCombo.Select("All", SAPbouiCOM.BoSearchKey.psk_ByValue)
                    oForm.PaneLevel = 1

                    strSQL = "Select * from " & newview '& " Where DocDate Between '" & oForm.Items.Item("11").Specific.value & "' AND '" & oForm.Items.Item("13").Specific.value & "' AND (Vendor='" & oForm.Items.Item("18").Specific.value & "' OR '" & oForm.Items.Item("18").Specific.value & "'='') "
                    oGrid1.DataTable.ExecuteQuery(strSQL)
                    oGrid1.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                    CType(oGrid1.Columns.Item("Vendor"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 2
                    CType(oGrid1.Columns.Item("DocEntry"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 46
                    Dim ColQty As SAPbouiCOM.EditTextColumn
                    ColQty = oGrid1.Columns.Item("Amount")
                    ColQty.ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
                    oForm.Items.Item("3").Top = oForm.Items.Item("6").Top + 25
                    oForm.Items.Item("5").Top = oForm.Items.Item("6").Top + 25
                    oForm.Items.Item("8").Top = oForm.Items.Item("6").Top
                    oForm.Items.Item("9").Top = oForm.Items.Item("6").Top
                    oForm.Items.Item("21").Top = oForm.Items.Item("6").Top + 20
                    oForm.Items.Item("21").Width = oForm.Items.Item("3").Width + 10
                    oForm.Items.Item("21").Height = oForm.Items.Item("3").Height + 10
                    For i = 0 To oGrid1.Columns.Count - 1
                        If oGrid1.Columns.Item(i).TitleObject.Caption = "Select" Then
                            oGrid1.Columns.Item(i).Editable = True
                        Else
                            oGrid1.Columns.Item(i).TitleObject.Sortable = True
                            oGrid1.Columns.Item(i).Editable = False
                            'oGrid.Columns.Item(i).TitleObject.Sortable = True
                        End If
                    Next
                    oForm.Freeze(False)
                Catch ex As Exception
                    oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
                Finally
                    oForm.Mode = SAPbouiCOM.BoFormMode.fm_OK_MODE
                    oForm.Freeze(False)
                End Try
        End Select
    End Sub
#End Region

#Region "Item Events"
    Public Overrides Sub ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean)
        Try
            Select Case pVal.BeforeAction
                Case False
                    Select Case pVal.EventType

                        Case SAPbouiCOM.BoEventTypes.et_FORM_LOAD
                            oForm = oApplication.SBO_Application.Forms.Item(_FormUID)
                            'oGrid1 = oForm.Items.Item("3").Specific
                            'oGrid2 = oForm.Items.Item("5").Specific

                        Case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST
                            Me.oCFLEvent = CType(pVal, SAPbouiCOM.IChooseFromListEvent)
                            If Not Me.oCFLEvent.SelectedObjects Is Nothing Then
                                If Me.oCFLEvent.ItemUID = "18" Then
                                    oDS = oForm.DataSources.DBDataSources.Item("OINV")
                                    oDS.SetValue("CardCode", 0, Me.oCFLEvent.SelectedObjects.GetValue(0, 0).ToString())
                                End If
                            End If

                        Case SAPbouiCOM.BoEventTypes.et_FORM_RESIZE
                            oForm = oApplication.SBO_Application.Forms.Item(_FormUID)
                            oForm.Items.Item("3").Top = oForm.Items.Item("6").Top + 25
                            oForm.Items.Item("5").Top = oForm.Items.Item("6").Top + 25
                            oForm.Items.Item("8").Top = oForm.Items.Item("6").Top
                            oForm.Items.Item("9").Top = oForm.Items.Item("6").Top
                            oForm.Items.Item("21").Top = oForm.Items.Item("6").Top + 20
                            oForm.Items.Item("21").Width = oForm.Items.Item("3").Width + 10
                            oForm.Items.Item("21").Height = oForm.Items.Item("3").Height + 10


                        Case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT
                            Select Case pVal.ItemUID
                                Case "15"
                                    ProcId = oForm.Items.Item("20").Specific.value
                                    strSQL = "SELECT Code,Name,U_ACTIVE,U_OUTDIR,U_ARCHDIR,U_FILENAME,U_EXT,U_NEWVIEW,U_HISTVIEW,U_EXTLOGIC,U_VALIDVIEW FROM [@BOSBECONFIG] WHERE U_ACTIVE='Y' AND Code='" & oForm.Items.Item("15").Specific.selected.value & "' "
                                    oApplication.Utilities.ExecuteSQL(oRS, strSQL)
                                    oCombo = oForm.Items.Item("15").Specific
                                    If oRS.RecordCount > 0 Then
                                        output = oRS.Fields.Item(3).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                                        filename = oRS.Fields.Item(5).Value
                                        ext = oRS.Fields.Item(6).Value
                                        archive = oRS.Fields.Item(4).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                                        newview = oRS.Fields.Item(7).Value
                                        histview = oRS.Fields.Item(8).Value
                                        extSP = oRS.Fields.Item(9).Value
                                        validview = oRS.Fields.Item(10).Value
                                        oForm.Items.Item("22").Specific.value = output '& "\" & filename & ProcId & "." & ext 'oRS.Fields.Item(3).Value
                                        oForm.Items.Item("16").Specific.value = oRS.Fields.Item(1).Value
                                    End If
                            End Select
                    End Select



                Case True
                    Select Case pVal.EventType
                        Case SAPbouiCOM.BoEventTypes.et_KEY_DOWN
                            Select Case pVal.ItemUID
                                Case "20"
                                    Select Case pVal.CharPressed
                                        Case "9"
                                            If oForm.Items.Item("20").Specific.value = "" Then
                                                BubbleEvent = False
                                                oApplication.SBO_Application.ActivateMenuItem("7425")
                                            End If
                                    End Select
                            End Select
                        Case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED
                            Select Case pVal.ItemUID
                                'Case "12"
                                '    OpenDirectory()
                                '    oDS = oForm.DataSources.DBDataSources.Item("OINV")
                                '    If FolderPath <> "" Then
                                '        oDS.SetValue("Comments", 0, FolderPath)
                                '    End If
                                Case "8"
                                    oGrid1 = oForm.Items.Item("3").Specific
                                    oGrid2 = oForm.Items.Item("5").Specific
                                    oGrid1.DataTable.Clear()
                                    oForm.PaneLevel = 1

                                Case "9"
                                    oGrid1 = oForm.Items.Item("3").Specific
                                    oGrid2 = oForm.Items.Item("5").Specific
                                    oGrid2.DataTable.Clear()
                                    oForm.PaneLevel = 2

                                Case "6"
                                    oGrid1 = oForm.Items.Item("3").Specific
                                    oGrid2 = oForm.Items.Item("5").Specific
                                    oForm.Freeze(True)
                                    Try
                                        If oForm.PaneLevel = 1 Then
                                            oProgressBar = oApplication.SBO_Application.StatusBar.CreateProgressBar("Selecting records...", oGrid1.DataTable.Rows.Count - 1, True)
                                            oProgressBar.Value = 0
                                            oProgressBar.Text = "Selecting records...please wait"
                                            If oForm.Items.Item("23").Specific.selected.value = "All" Then
                                                For i = 0 To oGrid1.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    oGrid1.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                Next
                                            ElseIf oForm.Items.Item("23").Specific.selected.value = "Vendor" Then
                                                Dim k As Integer = oGrid1.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid1.Columns.Item("Vendor")

                                                Dim value As String = oEditCol.GetText(k)   'oGrid1.DataTable.Columns.Item("Vendor").Cells.Item(k).Value
                                                For i = 0 To oGrid1.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If oGrid1.DataTable.Columns.Item("Vendor").Cells.Item(i).Value = value Then
                                                        oGrid1.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            ElseIf oForm.Items.Item("23").Specific.selected.value = "Due Date" Then
                                                Dim k As Integer = oGrid1.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid1.Columns.Item("Due Date")

                                                Dim value As String = oEditCol.GetText(k)  'oGrid1.DataTable.Columns.Item("Due Date").Cells.Item(k).Value
                                                For i = 0 To oGrid1.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If CDate(oGrid1.DataTable.Columns.Item("Due Date").Cells.Item(i).Value.ToString()).ToString("yyyyMMdd") = value Then
                                                        oGrid1.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            ElseIf oForm.Items.Item("23").Specific.selected.value = "Bank Code" Then
                                                Dim k As Integer = oGrid1.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid1.Columns.Item("Bank Code")

                                                Dim value As String = oEditCol.GetText(k)   'oGrid1.DataTable.Columns.Item("Bank Code").Cells.Item(k).Value
                                                For i = 0 To oGrid1.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If oGrid1.DataTable.Columns.Item("Bank Code").Cells.Item(i).Value = value Then
                                                        oGrid1.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            End If
                                        Else
                                            oProgressBar = oApplication.SBO_Application.StatusBar.CreateProgressBar("Selecting records...", oGrid2.DataTable.Rows.Count - 1, True)
                                            oProgressBar.Value = 0
                                            oProgressBar.Text = "Selecting records...please wait"
                                            If oForm.Items.Item("24").Specific.selected.value = "All" Then
                                                For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                Next
                                            ElseIf oForm.Items.Item("24").Specific.selected.value = "Vendor" Then
                                                Dim k As Integer = oGrid2.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid2.Columns.Item("Vendor")

                                                Dim value As String = oEditCol.GetText(k)   'oGrid2.DataTable.Columns.Item("Vendor").Cells.Item(k).Value
                                                For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If oGrid2.DataTable.Columns.Item("Vendor").Cells.Item(i).Value = value Then
                                                        oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            ElseIf oForm.Items.Item("24").Specific.selected.value = "Process ID" Then
                                                Dim k As Integer = oGrid2.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid2.Columns.Item("Process ID")

                                                Dim value As String = oEditCol.GetText(k)  'oGrid2.DataTable.Columns.Item("Process ID").Cells.Item(k).Value
                                                For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If oGrid2.DataTable.Columns.Item("Process ID").Cells.Item(i).Value = value Then
                                                        oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            ElseIf oForm.Items.Item("24").Specific.selected.value = "Bank Code" Then
                                                Dim k As Integer = oGrid2.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid2.Columns.Item("Bank Code")

                                                Dim value As String = oEditCol.GetText(k)  'oGrid2.DataTable.Columns.Item("Bank Code").Cells.Item(k).Value
                                                For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If oGrid2.DataTable.Columns.Item("Bank Code").Cells.Item(i).Value = value Then
                                                        oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            ElseIf oForm.Items.Item("24").Specific.selected.value = "Due Date" Then
                                                Dim k As Integer = oGrid2.Rows.SelectedRows.Item(0, SAPbouiCOM.BoOrderType.ot_RowOrder)
                                                Dim oEditCol As SAPbouiCOM.EditTextColumn
                                                oEditCol = oGrid2.Columns.Item("Due Date")

                                                Dim value As String = oEditCol.GetText(k)  'oGrid2.DataTable.Columns.Item("Due Date").Cells.Item(k).Value
                                                For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                    oProgressBar.Value = oProgressBar.Value + 1
                                                    If CDate(oGrid2.DataTable.Columns.Item("Due Date").Cells.Item(i).Value.ToString()).ToString("yyyyMMdd") = value Then
                                                        oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y"
                                                    End If
                                                Next
                                            End If
                                        End If
                                    Catch ex As Exception
                                        oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
                                    Finally
                                        oProgressBar.Stop()
                                        oApplication.SBO_Application.StatusBar.SetText("Process completed", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    End Try
                                    oForm.Freeze(False)

                                Case "7"
                                    oGrid1 = oForm.Items.Item("3").Specific
                                    oGrid2 = oForm.Items.Item("5").Specific
                                    oForm.Freeze(True)
                                    'oApplication.SBO_Application.StatusBar.SetText("Please wait......clearing records!", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                    'If oForm.PaneLevel = 1 Then
                                    '    For i = 0 To oGrid1.DataTable.Rows.Count - 1
                                    '        oGrid1.DataTable.Columns.Item("Select").Cells.Item(i).Value = "N"
                                    '    Next
                                    'Else
                                    '    For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                    '        oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "N"
                                    '    Next
                                    'End If
                                    'oApplication.SBO_Application.StatusBar.SetText("Records cleared!", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                    oForm.Items.Item("4").Click()
                                    oForm.Freeze(False)

                                Case "26"
                                    'OpenDirectory()
                                    'oDS = oForm.DataSources.DBDataSources.Item("OINV")
                                    'If FolderPath <> "" Then
                                    '    oDS.SetValue("PickRmrk", 0, FolderPath)
                                    'End If
                                    Process.Start("Explorer.exe", oForm.Items.Item("22").Specific.value)

                                Case "Update"
                                    oForm.Freeze(True)
                                    oGrid1 = oForm.Items.Item("3").Specific
                                    oGrid2 = oForm.Items.Item("5").Specific
                                    If oForm.PaneLevel = 1 Then

                                        If oGrid1.DataTable.Rows.Count > 0 Then
                                            Dim DocNums As String = ""
                                            oApplication.SBO_Application.StatusBar.SetText("Please wait......verifying data!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            Dim inc As Integer = 0
                                            Dim Total As Double = 0
                                            For i = 0 To oGrid1.DataTable.Rows.Count - 1
                                                If oGrid1.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y" Then
                                                    If DocNums = "" Then
                                                        inc = inc + 1
                                                        Total = Total + oGrid1.DataTable.Columns.Item("Amount").Cells.Item(i).Value
                                                        DocNums = oGrid1.DataTable.Columns.Item("DocEntry").Cells.Item(i).Value
                                                        BankAct = oGrid1.DataTable.Columns.Item("Bank Code").Cells.Item(i).Value
                                                    Else
                                                        inc = inc + 1
                                                        Total = Total + oGrid1.DataTable.Columns.Item("Amount").Cells.Item(i).Value
                                                        DocNums = DocNums & "," & oGrid1.DataTable.Columns.Item("DocEntry").Cells.Item(i).Value
                                                    End If
                                                End If

                                            Next
                                            oApplication.SBO_Application.StatusBar.SetText("Data verified.", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                            If DocNums <> "" Then
                                                strSQL = "Select * FROM " & validview & " WHERE DocEntry in (" & DocNums & ") "
                                                oApplication.Utilities.ExecuteSQL(RS, strSQL)
                                                If RS.RecordCount > 0 Then
                                                    'Dim p As Integer = p
                                                    'Dim msg As String = ""
                                                    'While RS.RecordCount > p
                                                    '    msg = msg & vbNewLine & RS.Fields.Item(1).Value
                                                    '    RS.MoveNext()
                                                    '    p = p + 1
                                                    'End While
                                                    'oApplication.SBO_Application.MessageBox("Validation faild due to " & vbNewLine & msg)
                                                    Me._Object = New clsErrorLogs
                                                    Me.OpenLookUpForm(xml_ErrorLogs)
                                                    CType(Me._Object, clsErrorLogs).FillForm(strSQL)
                                                Else
                                                    Dim Ret As Integer = oApplication.SBO_Application.MessageBox(CStr(inc) & " records selected and total amount : " & (Total.ToString("N")) & "  . Do you want to continue?", 1, "Yes", "No", "")
                                                    Select Case Ret
                                                        Case 1
                                                            Try
                                                                oProgressBar = oApplication.SBO_Application.StatusBar.CreateProgressBar("Initializing reprocess...", oGrid1.DataTable.Rows.Count - 1, True)
                                                                oProgressBar.Value = 0
                                                                oProgressBar.Text = "Starting export...please wait"
                                                                oProgressBar.Value = oProgressBar.Value + 1
                                                                'oApplication.SBO_Application.MessageBox(CStr(inc) & " records selected and total amount : - " & CStr(Total))
                                                                'oProgressBar.Text = CStr(inc) & " records selected and total amount :  " & CStr(Total)
                                                                ProcId = Date.Now.ToString("yyyyMMddhhmmss") 'oApplication.Utilities.getMaxCode("@BOSBELOG", "Code", True)
                                                                strSQL = "SELECT Code,Name,U_ACTIVE,U_OUTDIR,U_ARCHDIR,U_FILENAME,U_EXT,U_NEWVIEW,U_HISTVIEW,U_EXTLOGIC,U_VALIDVIEW FROM [@BOSBECONFIG] WHERE U_ACTIVE='Y' AND Code='" & oForm.Items.Item("15").Specific.selected.value & "' "
                                                                oApplication.Utilities.ExecuteSQL(oRS, strSQL)
                                                                oCombo = oForm.Items.Item("15").Specific
                                                                If oRS.RecordCount > 0 Then
                                                                    output = oRS.Fields.Item(3).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                                                                    filename = oRS.Fields.Item(5).Value
                                                                    ext = oRS.Fields.Item(6).Value
                                                                    archive = oRS.Fields.Item(4).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                                                                    newview = oRS.Fields.Item(7).Value
                                                                    histview = oRS.Fields.Item(8).Value
                                                                    extSP = oRS.Fields.Item(9).Value
                                                                    validview = oRS.Fields.Item(10).Value
                                                                    oForm.Items.Item("22").Specific.value = output '& "\" & filename & ProcId & "." & ext 'oRS.Fields.Item(3).Value
                                                                    oForm.Items.Item("16").Specific.value = oRS.Fields.Item(1).Value
                                                                    output = oForm.Items.Item("22").Specific.value
                                                                End If
                                                                oProgressBar.Value = oProgressBar.Value + 1
                                                                'strSQL = "select  connstr from  BOS_SQLCNFG"
                                                                'strSQL = "EXEC " & extSP & " '" & ProcId & "','" & DocNums & "' "
                                                                'oApplication.Utilities.ExecuteSQL(oRS, strSQL)
                                                                If oRS.RecordCount > 0 Then
                                                                    strSQL = "EXEC " & extSP & " '" & ProcId & "','" & DocNums & "' "
                                                                    Dim SQLcn As New SqlClient.SqlConnection
                                                                    Try
                                                                        SQLcn.ConnectionString = "Data Source=" & oApplication.Company.Server & ";Initial Catalog=" & oApplication.Company.CompanyDB & ";Integrated Security=true"  'oRS.Fields.Item(0).Value '"Initial Catalog=" & databaseName & ";Pooling=False;UID=" & dbUserName & ";Pwd=" & dbPassword & ";Data Source=" & serverName
                                                                        SQLcn.Open()
                                                                    Catch ex As Exception
                                                                        oApplication.SBO_Application.MessageBox(ex.Message)
                                                                    End Try

                                                                    Dim data As String = ""
                                                                    Dim dtTemp As DataTable
                                                                    dtTemp = openRS(strSQL, SQLcn)
                                                                    If dtTemp.Rows.Count > 0 Then
                                                                        For Each dr As DataRow In dtTemp.Rows
                                                                            data = dr.Item(0).ToString.Trim
                                                                        Next
                                                                    End If
                                                                    i = 0
                                                                    'Dim data As String = ""
                                                                    'While i < oRS.Fields.Count
                                                                    '    data = data & oRS.Fields.Item(i).Value
                                                                    '    i = i + 1
                                                                    'End While
                                                                    'Dim data As String = oRS.Fields.Item(0).Value.ToString() & oRS.Fields.Item(1).Value.ToString() & oRS.Fields.Item(2).Value.ToString()
                                                                    If data <> "" Then
                                                                        sw = IO.File.AppendText(output & "\" & filename & ProcId & "." & ext)
                                                                        sw.Write(data)
                                                                        sw.Flush()
                                                                        sw.Close()

                                                                        sw = IO.File.AppendText(archive & "\" & filename & ProcId & "." & ext)
                                                                        sw.WriteLine(data)

                                                                        sw.Flush()
                                                                        sw.Close()

                                                                        strSQL = "Insert into [@BOSBELOG] values ('" & ProcId & "','" & ProcId & "','Y','" & ProcId & "',GetDate(),'" & oForm.Items.Item("15").Specific.selected.value & "','" & oApplication.Company.UserName & "','" & BankAct & "','" & output & "','" & archive & "','" & filename & ProcId & "." & ext & "','" & DocNums & "') "
                                                                        oApplication.Utilities.ExecuteSQL(RS, strSQL)

                                                                        strSQL = "Update OVPM Set U_BOSBEDTM='" & ProcId & "' WHERE DocEntry in  (" & DocNums & ") "
                                                                        oApplication.Utilities.ExecuteSQL(RS, strSQL)

                                                                        'oApplication.SBO_Application.StatusBar.SetText("File exported", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                                                        oForm.Items.Item("4").Click()
                                                                    Else

                                                                        'oApplication.SBO_Application.StatusBar.SetText("File export procedure failed!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

                                                                    End If
                                                                End If
                                                            Catch ex As Exception
                                                            Finally
                                                                oProgressBar.Stop()
                                                                oApplication.SBO_Application.StatusBar.SetText("Process completed", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                                            End Try

                                                    End Select

                                                End If
                                            Else
                                                oApplication.SBO_Application.StatusBar.SetText("No records selected!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

                                            End If


                                        Else
                                            oApplication.SBO_Application.SetStatusBarMessage("Please refresh data")
                                        End If
                                    Else
                                        If oGrid2.DataTable.Rows.Count > 0 Then
                                            Dim DocNums As String = ""
                                            oApplication.SBO_Application.StatusBar.SetText("Please wait......verifying data!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
                                            Dim inc As Integer = 0
                                            Dim Total As Double = 0
                                            For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                If oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y" Then
                                                    If DocNums = "" Then
                                                        inc = inc + 1
                                                        Total = Total + oGrid2.DataTable.Columns.Item("Amount").Cells.Item(i).Value
                                                        DocNums = oGrid2.DataTable.Columns.Item("DocEntry").Cells.Item(i).Value
                                                        BankAct = oGrid2.DataTable.Columns.Item("Bank Code").Cells.Item(i).Value
                                                    Else
                                                        inc = inc + 1
                                                        Total = Total + oGrid2.DataTable.Columns.Item("Amount").Cells.Item(i).Value
                                                        DocNums = DocNums & "," & oGrid2.DataTable.Columns.Item("DocEntry").Cells.Item(i).Value
                                                    End If
                                                End If

                                            Next
                                            oApplication.SBO_Application.StatusBar.SetText("Data verified.", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)

                                            If DocNums <> "" Then
                                                strSQL = "Select * FROM " & validview & " WHERE DocEntry in (" & DocNums & ") "
                                                oApplication.Utilities.ExecuteSQL(RS, strSQL)
                                                If RS.RecordCount > 0 Then
                                                    'Dim p As Integer = p
                                                    'Dim msg As String = ""
                                                    'While RS.RecordCount > p
                                                    '    msg = msg & vbNewLine & RS.Fields.Item(1).Value
                                                    '    RS.MoveNext()
                                                    '    p = p + 1
                                                    'End While
                                                    'oApplication.SBO_Application.MessageBox("Validation faild due to " & vbNewLine & msg)
                                                    Me._Object = New clsErrorLogs
                                                    Me.OpenLookUpForm(xml_ErrorLogs)
                                                    CType(Me._Object, clsErrorLogs).FillForm(strSQL)
                                                Else
                                                    Dim Ret As Integer = oApplication.SBO_Application.MessageBox(CStr(inc) & " records selected and total amount : " & (Total.ToString("N")) & "  . Do you want to continue?", 1, "Yes", "No", "")
                                                    Select Case Ret
                                                        Case 1
                                                            Try
                                                                oProgressBar = oApplication.SBO_Application.StatusBar.CreateProgressBar("Initializing reprocess...", oGrid1.DataTable.Rows.Count - 1, True)
                                                                oProgressBar.Value = 0
                                                                oProgressBar.Text = "Starting export...please wait"
                                                                oProgressBar.Value = oProgressBar.Value + 1
                                                                'oApplication.SBO_Application.MessageBox(CStr(inc) & " records selected and total amount : - " & CStr(Total))
                                                                'oProgressBar.Text = CStr(inc) & " records selected and total amount :  " & CStr(Total)
                                                                ProcId = Date.Now.ToString("yyyyMMddhhmmss") 'oApplication.Utilities.getMaxCode("@BOSBELOG", "Code", True)
                                                                strSQL = "SELECT Code,Name,U_ACTIVE,U_OUTDIR,U_ARCHDIR,U_FILENAME,U_EXT,U_NEWVIEW,U_HISTVIEW,U_EXTLOGIC,U_VALIDVIEW FROM [@BOSBECONFIG] WHERE U_ACTIVE='Y' AND Code='" & oForm.Items.Item("15").Specific.selected.value & "' "
                                                                oApplication.Utilities.ExecuteSQL(oRS, strSQL)
                                                                oCombo = oForm.Items.Item("15").Specific
                                                                If oRS.RecordCount > 0 Then
                                                                    output = oRS.Fields.Item(3).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                                                                    filename = oRS.Fields.Item(5).Value
                                                                    ext = oRS.Fields.Item(6).Value
                                                                    archive = oRS.Fields.Item(4).Value '& "\" & oRS.Fields.Item(5).Value & oForm.Items.Item("20").Specific.value & "." & oRS.Fields.Item(6).Value
                                                                    newview = oRS.Fields.Item(7).Value
                                                                    histview = oRS.Fields.Item(8).Value
                                                                    extSP = oRS.Fields.Item(9).Value
                                                                    validview = oRS.Fields.Item(10).Value
                                                                    oForm.Items.Item("22").Specific.value = output '& "\" & filename & ProcId & "." & ext 'oRS.Fields.Item(3).Value
                                                                    oForm.Items.Item("16").Specific.value = oRS.Fields.Item(1).Value
                                                                    output = oForm.Items.Item("22").Specific.value
                                                                End If
                                                                oProgressBar.Value = oProgressBar.Value + 1
                                                                'strSQL = "select  connstr from  BOS_SQLCNFG"
                                                                'strSQL = "EXEC " & extSP & " '" & ProcId & "','" & DocNums & "' "
                                                                'oApplication.Utilities.ExecuteSQL(oRS, strSQL)
                                                                If oRS.RecordCount > 0 Then
                                                                    strSQL = "EXEC " & extSP & " '" & ProcId & "','" & DocNums & "' "
                                                                    Dim SQLcn As New SqlClient.SqlConnection
                                                                    Try
                                                                        SQLcn.ConnectionString = "Data Source=" & oApplication.Company.Server & ";Initial Catalog=" & oApplication.Company.CompanyDB & ";Integrated Security=true"  'oRS.Fields.Item(0).Value '"Initial Catalog=" & databaseName & ";Pooling=False;UID=" & dbUserName & ";Pwd=" & dbPassword & ";Data Source=" & serverName
                                                                        SQLcn.Open()
                                                                    Catch ex As Exception
                                                                        oApplication.SBO_Application.MessageBox(ex.Message)
                                                                    End Try

                                                                    Dim data As String = ""
                                                                    Dim dtTemp As DataTable
                                                                    dtTemp = openRS(strSQL, SQLcn)
                                                                    If dtTemp.Rows.Count > 0 Then
                                                                        For Each dr As DataRow In dtTemp.Rows
                                                                            data = dr.Item(0).ToString.Trim
                                                                        Next
                                                                    End If
                                                                    i = 0
                                                                    'Dim data As String = ""
                                                                    'While i < oRS.Fields.Count
                                                                    '    data = data & oRS.Fields.Item(i).Value
                                                                    '    i = i + 1
                                                                    'End While
                                                                    'Dim data As String = oRS.Fields.Item(0).Value.ToString() & oRS.Fields.Item(1).Value.ToString() & oRS.Fields.Item(2).Value.ToString()
                                                                    If data <> "" Then
                                                                        sw = IO.File.AppendText(output & "\" & filename & ProcId & "." & ext)
                                                                        sw.Write(data)
                                                                        sw.Flush()
                                                                        sw.Close()

                                                                        sw = IO.File.AppendText(archive & "\" & filename & ProcId & "." & ext)
                                                                        sw.WriteLine(data)

                                                                        sw.Flush()
                                                                        sw.Close()

                                                                        strSQL = "Insert into [@BOSBELOG] values ('" & ProcId & "','" & ProcId & "','Y','" & ProcId & "',GetDate(),'" & oForm.Items.Item("15").Specific.selected.value & "','" & oApplication.Company.UserName & "','" & BankAct & "','" & output & "','" & archive & "','" & filename & ProcId & "." & ext & "','" & DocNums & "') "
                                                                        oApplication.Utilities.ExecuteSQL(RS, strSQL)

                                                                        strSQL = "Update OVPM Set U_BOSBEDTM='" & ProcId & "' WHERE DocEntry in  (" & DocNums & ") "
                                                                        oApplication.Utilities.ExecuteSQL(RS, strSQL)

                                                                        'oApplication.SBO_Application.StatusBar.SetText("File exported", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                                                        oForm.Items.Item("8").Click()
                                                                    Else

                                                                        'oApplication.SBO_Application.StatusBar.SetText("File export procedure failed!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

                                                                    End If
                                                                End If
                                                            Catch ex As Exception
                                                            Finally
                                                                oProgressBar.Stop()
                                                                oApplication.SBO_Application.StatusBar.SetText("Process completed", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                                            End Try

                                                    End Select
                                                End If
                                            Else
                                                oApplication.SBO_Application.StatusBar.SetText("No records selected!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error)

                                            End If


                                        Else
                                            oApplication.SBO_Application.SetStatusBarMessage("Please refresh data")
                                        End If

                                    End If

                                    oForm.Freeze(False)
                                Case "25"
                                    oForm.Freeze(True)
                                    oGrid1 = oForm.Items.Item("3").Specific
                                    oGrid2 = oForm.Items.Item("5").Specific
                                    If oGrid2.DataTable.Rows.Count > 0 And oForm.PaneLevel = 2 Then
                                        Try
                                            oProgressBar = oApplication.SBO_Application.StatusBar.CreateProgressBar("Reprocess...", oGrid2.DataTable.Rows.Count - 1, True)
                                            oProgressBar.Value = 0
                                            oProgressBar.Text = "Sending data for reprocess...please wait"
                                            For i = 0 To oGrid2.DataTable.Rows.Count - 1
                                                oProgressBar.Value = oProgressBar.Value + 1
                                                If oGrid2.DataTable.Columns.Item("Select").Cells.Item(i).Value = "Y" Then
                                                    'If oGrid2.DataTable.Columns.Item("DocEntry").Cells.Item(i).Value <> "" Then
                                                    strSQL = "Update OVPM Set U_BOSBEDTM='' WHERE DocEntry in  (" & oGrid2.DataTable.Columns.Item("DocEntry").Cells.Item(i).Value & ") "
                                                    oApplication.Utilities.ExecuteSQL(RS, strSQL)
                                                    'End If
                                                End If

                                            Next
                                            oForm.Items.Item("8").Click()

                                        Catch ex As Exception
                                        Finally
                                            oProgressBar.Stop()
                                            oApplication.SBO_Application.StatusBar.SetText("Process completed....please refresh data!", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                                        End Try
                                    End If

                                Case "4"
                                    Try

                                        oForm.Freeze(True)
                                        oGrid1 = oForm.Items.Item("3").Specific
                                        oGrid2 = oForm.Items.Item("5").Specific
                                        If oForm.PaneLevel = 1 Then
                                            oGrid1.DataTable.Clear()
                                            strSQL = "Select * from " & newview & " Where ([Due Date] >= '" & oForm.Items.Item("11").Specific.value & "' OR '" & oForm.Items.Item("11").Specific.value & "'='' ) AND ([Due Date]<='" & oForm.Items.Item("13").Specific.value & "' OR '" & oForm.Items.Item("13").Specific.value & "'='' ) AND (Vendor='" & oForm.Items.Item("18").Specific.value & "' OR '" & oForm.Items.Item("18").Specific.value & "'='') "
                                            oGrid1.DataTable.ExecuteQuery(strSQL)
                                            oGrid1.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                                            CType(oGrid1.Columns.Item("Vendor"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 2
                                            CType(oGrid1.Columns.Item("DocEntry"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 46
                                            Dim ColQty As SAPbouiCOM.EditTextColumn
                                            ColQty = oGrid1.Columns.Item("Amount")
                                            ColQty.ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
                                            oForm.Items.Item("3").Top = oForm.Items.Item("6").Top + 25
                                            oForm.Items.Item("5").Top = oForm.Items.Item("6").Top + 25
                                            oForm.Items.Item("8").Top = oForm.Items.Item("6").Top
                                            oForm.Items.Item("9").Top = oForm.Items.Item("6").Top
                                            oForm.Items.Item("21").Top = oForm.Items.Item("6").Top + 20
                                            oForm.Items.Item("21").Width = oForm.Items.Item("3").Width + 10
                                            oForm.Items.Item("21").Height = oForm.Items.Item("3").Height + 10
                                            For i = 0 To oGrid1.Columns.Count - 1
                                                If oGrid1.Columns.Item(i).TitleObject.Caption = "Select" Then
                                                    oGrid1.Columns.Item(i).Editable = True
                                                Else
                                                    oGrid1.Columns.Item(i).TitleObject.Sortable = True
                                                    oGrid1.Columns.Item(i).Editable = False
                                                    'oGrid.Columns.Item(i).TitleObject.Sortable = True
                                                End If
                                            Next
                                        Else
                                            oGrid2.DataTable.Clear()
                                            'strSQL = "Select 'N' [Select],U_ProcID [Process ID],U_PROCDTM [Process Date],Code [Process Code],U_UserId [UserId],U_BankAcct [Bank Code],U_Payprcd [Payments Processed] from [@BOSBELOG] WHERE U_ProcID='" & oForm.Items.Item("20").Specific.value & "' OR '" & oForm.Items.Item("20").Specific.value & "' ='' "
                                            strSQL = "Select * FROM " & histview & " WHERE ([Due Date] >= '" & oForm.Items.Item("11").Specific.value & "' OR '" & oForm.Items.Item("11").Specific.value & "'='' ) AND ([Due Date]<='" & oForm.Items.Item("13").Specific.value & "' OR '" & oForm.Items.Item("13").Specific.value & "'='' ) AND (Vendor='" & oForm.Items.Item("18").Specific.value & "' OR '" & oForm.Items.Item("18").Specific.value & "'='') AND ([Process ID]='" & oForm.Items.Item("20").Specific.value & "' OR '" & oForm.Items.Item("20").Specific.value & "' ='')  "
                                            oGrid2.DataTable.ExecuteQuery(strSQL)
                                            oGrid2.Columns.Item("Select").Type = SAPbouiCOM.BoGridColumnType.gct_CheckBox
                                            CType(oGrid2.Columns.Item("Vendor"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 2
                                            CType(oGrid2.Columns.Item("DocEntry"), SAPbouiCOM.EditTextColumn).LinkedObjectType = 46
                                            Dim ColQty As SAPbouiCOM.EditTextColumn
                                            ColQty = oGrid2.Columns.Item("Amount")
                                            ColQty.ColumnSetting.SumType = SAPbouiCOM.BoColumnSumType.bst_Auto
                                            oForm.Items.Item("3").Top = oForm.Items.Item("6").Top + 25
                                            oForm.Items.Item("5").Top = oForm.Items.Item("6").Top + 25
                                            oForm.Items.Item("8").Top = oForm.Items.Item("6").Top
                                            oForm.Items.Item("9").Top = oForm.Items.Item("6").Top
                                            oForm.Items.Item("21").Top = oForm.Items.Item("6").Top + 20
                                            oForm.Items.Item("21").Width = oForm.Items.Item("3").Width + 10
                                            oForm.Items.Item("21").Height = oForm.Items.Item("3").Height + 10
                                            For i = 0 To oGrid2.Columns.Count - 1
                                                If oGrid2.Columns.Item(i).TitleObject.Caption = "Select" Then
                                                    oGrid2.Columns.Item(i).Editable = True
                                                Else
                                                    oGrid2.Columns.Item(i).TitleObject.Sortable = True
                                                    oGrid2.Columns.Item(i).Editable = False
                                                    'oGrid.Columns.Item(i).TitleObject.Sortable = True
                                                End If
                                            Next
                                        End If
                                        oForm.Freeze(False)

                                    Catch ex As Exception
                                        oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
                                    Finally
                                        oForm.Freeze(False)
                                    End Try


                            End Select
                    End Select
            End Select
        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        Finally
            oForm.Freeze(False)
        End Try
    End Sub
#End Region

#Region "Open RecordSet"
    Public Function openRS(ByVal sql As String, ByVal SQLcn As SqlClient.SqlConnection, Optional ByRef dt As DataTable = Nothing) As DataTable
        Try
            dt = New DataTable
            If dt Is Nothing Then
                dt = New DataTable
            End If
            Dim da As New SqlClient.SqlDataAdapter

            da.SelectCommand = New SqlClient.SqlCommand(sql, SQLcn)
            da.Fill(dt)
        Catch ex As Exception
            'sw = IO.File.AppendText(logPath & "\File Export Error" & " " & Format(Date.Today, "MMddyyyy").ToString & ".txt")
            'sw.WriteLine("File Export failed due to " & ex.Message)
            'sw.Flush()
            'sw.Close()
        End Try
        Return dt
    End Function
#End Region


#Region "Show Folder Dailog"
    Private Sub showFolderDialog()
        Try
            objDialogBox = New System.Windows.Forms.FolderBrowserDialog
            objProcess = System.Diagnostics.Process.GetProcessesByName("SAP Business One")
            If objProcess.Length <> 0 Then
                'For intLoop = 0 To objProcess.Length - 1
                MyWindow = New WindowWrapper(objProcess(intLoop).MainWindowHandle)
                'With objDialogBox
                '    .RootFolder = Environment.SpecialFolder.MyComputer
                'End With
                If objDialogBox.ShowDialog(MyWindow) = DialogResult.OK Then
                    FolderPath = objDialogBox.SelectedPath
                Else
                    FolderPath = ""
                End If
                'Next
            End If
        Catch ex As System.Exception
            oApplication.SBO_Application.StatusBar.SetText(ex.Message)
        Finally
            MyWindow = Nothing
            objProcess = Nothing
            objDialogBox = Nothing
            System.Threading.Thread.CurrentThread.Abort()
        End Try
    End Sub
#End Region

#Region "Show File Dailog"
    Private Sub showFileDialog()
        Try

            Dim objFileDialogBox As System.Windows.Forms.OpenFileDialog
            objFileDialogBox = New System.Windows.Forms.OpenFileDialog
            With objFileDialogBox
                .Filter = "Excel Worksheets (*.xlsx)|*.xlsx|All files (*.*)|*.*"
                .FilterIndex = 1
                .InitialDirectory = "C:\"
                .Title = "Open File"
                .CheckFileExists = False
            End With

            objProcess = System.Diagnostics.Process.GetProcessesByName("SAP Business One")
            If objProcess.Length <> 0 Then
                'For intLoop = 0 To objProcess.Length - 1
                MyWindow = New WindowWrapper(objProcess(intLoop).MainWindowHandle)
                'With objDialogBox
                '    .RootFolder = Environment.SpecialFolder.MyComputer
                'End With
                If objFileDialogBox.ShowDialog(MyWindow) = DialogResult.OK Then
                    FolderPath = objFileDialogBox.FileName
                Else
                    FolderPath = ""
                End If
                'Next
            End If
        Catch ex As System.Exception
            oApplication.SBO_Application.StatusBar.SetText(ex.Message)
        Finally
            MyWindow = Nothing
            objProcess = Nothing
            objDialogBox = Nothing
            System.Threading.Thread.CurrentThread.Abort()
        End Try
    End Sub
#End Region

#Region "Call Open Dialog Box"
    Private Function OpenDirectory() As String
        Try
            Dim objFileDialogThread As System.Threading.Thread
            objFileDialogThread = New System.Threading.Thread(AddressOf showFolderDialog)
            objFileDialogThread.SetApartmentState(ApartmentState.STA)
            objFileDialogThread.Start()
            objFileDialogThread.Join()
            Return FolderPath
        Catch ex As System.Exception
            oApplication.SBO_Application.StatusBar.SetText(ex.Message)
            Return ""
        End Try
    End Function
#End Region

#Region "Call Open File Dialog Box"
    Private Function OpenFile() As String
        Try
            Dim objFileDialogThread As System.Threading.Thread
            objFileDialogThread = New System.Threading.Thread(AddressOf showFileDialog)
            objFileDialogThread.SetApartmentState(ApartmentState.STA)
            objFileDialogThread.Start()
            objFileDialogThread.Join()
            Return FolderPath
        Catch ex As System.Exception
            oApplication.SBO_Application.StatusBar.SetText(ex.Message)
            Return ""
        End Try
    End Function
#End Region


#Region "Release Object"
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
#End Region

End Class
