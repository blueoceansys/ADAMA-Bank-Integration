Public Class clsSystemForms

#Region "Definitions"
    Private oForm As SAPbouiCOM.Form
    Private oItem1, GOD_NewItem, oItem, oNewItem As SAPbouiCOM.Item
    Private oExistingItem As SAPbouiCOM.Item
    Private oStatic As SAPbouiCOM.StaticText
    Private oEdit As SAPbouiCOM.EditText
    Private oButton As SAPbouiCOM.Button
    Private oButton1 As SAPbouiCOM.ButtonCombo
    Private oChkBox As SAPbouiCOM.CheckBox
    Private oFolder As SAPbouiCOM.Folder
    Private oMatrix As SAPbouiCOM.Matrix
    Private oColumn As SAPbouiCOM.Column
    Private oColumns As SAPbouiCOM.Columns
    Private oComboBox As SAPbouiCOM.ComboBox
    Private oDBDataSrc, oDBDSource As SAPbouiCOM.DBDataSource
    Private oUSDSource As SAPbouiCOM.UserDataSource
    Private oLink As SAPbouiCOM.LinkedButton
    Dim i As Integer
    Dim ors As SAPbobsCOM.Recordset
#End Region

#Region "Functions"

#Region "Add Items To Stystem Forms"
    Public Sub AddItems(ByVal FormType As Integer, ByVal FormUID As String)
        Select Case FormType
            Case frm_Authorization
                AddItemsToAuthorization(FormUID)

            Case frm_BusinessMaster
                AddItemsToBP(FormUID)

            Case frm_AR_Credit_Memo, frm_ARInvoice
                AddItemsToAR(FormUID)
        End Select
    End Sub
#End Region

#Region "Copy Authorization Structure"
    Private Sub AddItemsToAuthorization(ByVal sFormUID As String)
        Try
            oForm = oApplication.SBO_Application.Forms.Item(sFormUID)
            'oDBDSource = oForm.DataSources.DBDataSources.Add("OPKL")

            oItem = oForm.Items.Add("AuthStr", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem1 = oForm.Items.Item("2")
            oItem.Top = oItem1.Top
            oItem.Height = oItem1.Height
            oItem.Width = oItem1.Width + 100
            oItem.Left = oItem1.Left + oItem1.Width + 2
            oButton = oItem.Specific
            oButton.Caption = "Copy Authorization Structure"

        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
#End Region

#Region "BP"
    Private Sub AddItemsToBP(ByVal sFormUID As String)
        Try
            oForm = oApplication.SBO_Application.Forms.Item(sFormUID)
            'oDBDSource = oForm.DataSources.DBDataSources.Add("OPKL")

            oItem = oForm.Items.Add("COPLN", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem1 = oForm.Items.Item("1470002082")
            oItem.Top = oItem1.Top - 15
            oItem.Height = 14
            oItem.Width = oItem1.Width + 10
            oItem.Left = oItem1.Left
            oItem.FromPane = 6
            oItem.ToPane = 6
            oButton = oItem.Specific
            oButton.Caption = "Customer Price List Link"

        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
#End Region

#Region "AR"
    Private Sub AddItemsToAR(ByVal sFormUID As String)
        Try
            oForm = oApplication.SBO_Application.Forms.Item(sFormUID)
            'oDBDSource = oForm.DataSources.DBDataSources.Add("OPKL")

            oItem = oForm.Items.Add("UDF", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
            oItem1 = oForm.Items.Item("2")
            oItem.Top = oItem1.Top
            oItem.Height = oItem1.Height
            oItem.Width = oItem1.Width + 50
            oItem.Left = oItem1.Left + oItem1.Width + 2
            oButton = oItem.Specific
            oButton.Caption = "Override"

        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
#End Region

#End Region

End Class