Imports System.Data
Imports System.Data.SqlClient


Public Module modVariables
    Public oApplication As clsListener
    Public strSQL As String
    Public SOCardCode, ARCMCardCode, ServCardCode As String
    Public Autopress As String = "No"

    'Public cfl_Text As String
    'Public cfl_Btn As String
    'Public formID As String = ""
    'Public row As Integer
    'Public sw As IO.TextWriter
    'Public spath As String = IO.Directory.GetCurrentDirectory
    ''Public objSAPB1Handler As New HandleCall
    'Public objDBCon, objDBCon1, objDBCon2, objDBCon3 As New SqlClient.SqlConnection
    ''Public objSysEnv As New clsSysEnv
    'Public objSAPDB As SAPbobsCOM.Company
    'Public intCompanyNumber As Integer = 0
    'Public objSAPDBTarget(4) As SAPbobsCOM.Company
    'Public objAsseTrackerDB As SqlClient.SqlConnection
    'Dim blnDateCheckDone As Boolean

    'Sysytem Forms
    'Public Const frm_Opportunity As Integer = 320
    'Public Const frm_Alert As Integer = 198
    Public Const frm_BusinessMaster As Integer = 134
    Public Const frm_PURCHASE_ORDER As Integer = 142
    'Public Const frm_GOODS_RECEIPT_PO As Integer = 143
    'Public Const frm_NegPrch_ORDER As Integer = -142
    'Public Const frm_GOODS_RECEIPT As Integer = 721
    'Public Const frm_GOODS_RECEIPT1 As Integer = -721
    'Public Const frm_SERVICE_CALL As Integer = 60110
    'Public Const frm_Production_Order As Integer = 65211
    Public Const frm_DELIVERY As Integer = 140
    'Public Const frm_SALES_QUOTATION As Integer = 149
    Public Const frm_Authorization As Integer = 951
    'Public Const frm_InventoryTransfer As Integer = 940
    Public Const frm_ARInvoice As Integer = 133
    Public Const frm_SALES_ORDER As Integer = 139
    'Public Const frm_SALES_ORDER1 As Integer = -139
    'Public Const frm_Item_Master As Integer = 150
    'Public Const frm_AP_INVOICE As Integer = 141
    'Public Const frm_RETURN As Integer = 180
    'Public Const frm_GOODS_RETURN As Integer = 182
    'Public Const frm_AR_DownPayment_Invoice As Integer = 65300
    'Public Const frm_AP_DownPayment_Invoice As Integer = 65301
    'Public Const frm_Payment_Invoice As Integer = 60090
    Public Const frm_AR_Credit_Memo As Integer = 179
    Public Const frm_AP_Credit_Memo As Integer = 181
    'Public Const frm_InComingPayment As Integer = 170
    'Public Const frm_OutgoingPayment As Integer = 426
    Public Const frm_ServiceCall As Integer = 60110
    Public Const frm_LandedCost As Integer = 992
    Public Const frm_SALES_OPPURTUNITY As Integer = 320


    'User Defined Forms

    Public Const frm_Config As String = "Config"
    Public Const frm_ApproveOrd As String = "ApproveOrd"
    Public Const frm_eInvoice As String = "eInvoice"

    'System Menus

    'Public Const mnu_Item_Master As String = "3073"
    'Public Const mnu_Service_Call As String = "3587"
    Public Const mnu_FIND As String = "1281"
    Public Const mnu_ADD As String = "1282"
    Public Const mnu_NEXT As String = "1288"
    Public Const mnu_PREVIOUS As String = "1289"
    Public Const mnu_FIRST As String = "1290"
    Public Const mnu_LAST As String = "1291"
    Public Const mnu_ADD_ROW As String = "1292"
    Public Const mnu_DELETE_ROW As String = "1293"
    'Public Const mnu_ARINVOICE As String = "2053"

    'User Menus
    'Public Const mnu_EnqIndent As String = "GP_01"
    'Public Const mnu_PurchaseRequisition As String = "GP_02"
    'Public Const mnu_RFQ As String = "GP_03"
    'Public Const mnu_QuotCompareRpt As String = "GP_04"
    'Public Const mnu_QuotCompareConfirm As String = "GP_05"
    'Public Const mnu_CostEstRpt As String = "GP_06"
    Public Const mnu_Config As String = "InvntConfig"
    Public Const mnu_APInv As String = "APInv"
    Public Const mnu_CSVUpload As String = "CSVUpload"
    Public Const mnu_VARS As String = "VARSTransaction"
    Public Const mnu_ImportVARS As String = "ImportVARS"
    Public Const mnu_ApproveCM As String = "ApproveCM"
    Public Const mnu_ApproveAP As String = "ApproveAP"
    Public Const mnu_AltItem As String = "AltItem"
    Public Const mnu_UpdateItmGrp As String = "UpdateItmGrp"
    Public Const mnu_BankExtract As String = "BankExtract"

    'User Form XMLs
    Public Const xml_Config As String = "Config.xml"
    Public Const xml_MRPT As String = "MRPT.xml"
    Public Const xml_COPLN As String = "COPLN.xml"
    Public Const xml_BankExtract As String = "BankExtract.xml"
    Public Const xml_CSVUpload As String = "CSVUpload.xml"
    Public Const xml_APInv As String = "APInv.xml"
    Public Const xml_ApproveAP As String = "ApproveAP.xml"
    Public Const xml_ErrorLogs As String = "ErrorLogs.xml"
    Public Const xml_AltItem As String = "AltItem.xml"
    Public Const xml_UpdateItmGrp As String = "UpdateItmGrp.xml"
    Public Const xml_UDF As String = "UDF.xml"
    Public Const xml_eInvoice As String = "eInvoice.xml"

    'User Defined Objects
    'Public Const UDO_Enquiry_Indent As String = "UDO_EnqIndent"
    'Public Const UDO_Purchase_Req As String = "UDO_PurReq"
    'Public Const UDO_RFQ As String = "UDO_RFQ"
    'Public Const UDO_Cost_Estimation As String = "UDO_CostEstimation"
    'Public Const UDO_Job_Handover As String = "UDO_JobHandover"

    'System Business Objects Type

    'Public Const Service_businessObject As String = "191"
    'Public Const PO_businessObject As String = "202"

    'Keys
    'Public Const TAB As Integer = 9
    'Public Const SHIFT_F2 As String = "+{F2}"

End Module


