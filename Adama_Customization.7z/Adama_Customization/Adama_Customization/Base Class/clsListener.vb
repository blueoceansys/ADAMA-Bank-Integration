Public Class clsListener
    Inherits Object

    Private ThreadClose As New Threading.Thread(AddressOf CloseApp)
    Private WithEvents _SBO_Application As SAPbouiCOM.Application
    Private _Company As SAPbobsCOM.Company
    Private _Utilities As clsUtilities
    Private _Collection As Hashtable
    Private _LookUpCollection As Hashtable
    Private _FormUID As String
    Private _FormUID1 As String

    Private oMenuObject As Object
    Private oItemObject As Object
    Private oSystemForms As Object
    Private oFormObject As Object
    Private str As String
    Dim arr As Array
    Dim oItem1 As SAPbouiCOM.MenuItem
    Dim oItem2 As SAPbouiCOM.Item
    Dim oButton1 As SAPbouiCOM.Button
    Dim oGrid As SAPbouiCOM.Grid
    Protected _Object As Object
    Dim oForm1, oForm As SAPbouiCOM.Form

#Region "New"
    Public Sub New()
        MyBase.New()
        Try
            _Company = New SAPbobsCOM.Company
            _Utilities = New clsUtilities
            _Collection = New Hashtable(10, 0.5)
            _LookUpCollection = New Hashtable(10, 0.5)
            oSystemForms = New clsSystemForms
            SetApplication()

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Public Properties"

    Public ReadOnly Property SBO_Application() As SAPbouiCOM.Application
        Get
            Return _SBO_Application
        End Get
    End Property

    Public ReadOnly Property Company() As SAPbobsCOM.Company
        Get
            Return _Company
        End Get
    End Property

    Public ReadOnly Property Utilities() As clsUtilities
        Get
            Return _Utilities
        End Get
    End Property

    Public ReadOnly Property Collection() As Hashtable
        Get
            Return _Collection
        End Get
    End Property

    Public ReadOnly Property LookUpCollection() As Hashtable
        Get
            Return _LookUpCollection
        End Get
    End Property

    'Public Property formid1() As String
    '    Get
    '        Return str
    '    End Get
    '    Set(ByVal Value As String)
    '        Str = Value
    '    End Set

    'End Property
#End Region

#Region "Menu Event"
    Private Sub SBO_Application_MenuEvent(ByRef pVal As SAPbouiCOM.MenuEvent, ByRef BubbleEvent As Boolean) Handles _SBO_Application.MenuEvent
        Try
            _FormUID = oApplication.SBO_Application.Forms.ActiveForm.UniqueID
            Select Case pVal.BeforeAction
                Case False
                    Select Case pVal.MenuUID
                        '########## Menu For NACHA Import ###################
                        
                        Case "BankExtract"
                            oMenuObject = New clsBankExtract
                            Utilities.LoadForm(oMenuObject, xml_BankExtract)
                            oMenuObject.MenuEvent(pVal, BubbleEvent)


                            '########## Menu For VARS Transaction ###################


                            '#############################################################
                        Case mnu_ADD, mnu_FIND, mnu_FIRST, mnu_LAST, mnu_NEXT, mnu_PREVIOUS, mnu_ADD_ROW, mnu_DELETE_ROW
                            If _Collection.ContainsKey(_FormUID) Then
                                oMenuObject = _Collection.Item(_FormUID)
                                oMenuObject.MenuEvent(pVal, BubbleEvent)
                            End If

                    End Select
                Case True
                    Select Case pVal.MenuUID
                        Case mnu_ADD_ROW, mnu_DELETE_ROW
                            If _Collection.ContainsKey(_FormUID) Then
                                oMenuObject = _Collection.Item(_FormUID)
                                oMenuObject.MenuEvent(pVal, BubbleEvent)
                            End If
                    End Select
            End Select
        Catch ex As Exception
            Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oMenuObject = Nothing
        End Try
    End Sub
#End Region

#Region "Item Event"
    Private Sub SBO_Application_ItemEvent(ByVal FormUID As String, ByRef pVal As SAPbouiCOM.ItemEvent, ByRef BubbleEvent As Boolean) Handles _SBO_Application.ItemEvent
        Try

            If pVal.BeforeAction = False And pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_LOAD Then
                Select Case pVal.FormTypeEx
                   
                        '###### Authorization #################################
                    'Case frm_BusinessMaster
                    '    oSystemForms.AddItems(frm_BusinessMaster, FormUID)
                    '    If Not _Collection.ContainsKey(FormUID) Then
                    '        oItemObject = New clsBP
                    '        oItemObject.FrmUID = FormUID
                    '        _Collection.Add(FormUID, oItemObject)
                    '    End If

                   

                    Case "BankExtract"
                        If Not _Collection.ContainsKey(FormUID) Then
                            oItemObject = New clsBankExtract
                            oItemObject.FrmUID = FormUID
                            _Collection.Add(FormUID, oItemObject)
                        End If
                        '#####################################################
                End Select
            End If

            'If pVal.FormTypeEx = "UDF" And pVal.EventType = SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED Then
            '    Select pVal.ItemUID

            '        Case "OK"
            '            Try
            '                Dim ors As SAPbobsCOM.Recordset
            '                oForm = oApplication.SBO_Application.Forms.Item(FormUID)
            '                oApplication.SBO_Application.StatusBar.SetText("Please wait.........updating UDF's!", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            '                For i = 0 To oGrid.DataTable.Rows.Count - 1
            '                    Dim s As String = ""
            '                    For j = 0 To oGrid.DataTable.Columns.Count - 1
            '                        If s = "" Then
            '                            s = " '" & oGrid.DataTable.Columns.Item(j).Cells.Item(i).Value & "' "
            '                        Else
            '                            s = s & " , " & " '" & oGrid.DataTable.Columns.Item(j).Cells.Item(i).Value & "' "
            '                        End If
            '                    Next
            '                    oApplication.Utilities.ExecuteSQL(ors, "Exec BOS_UpdateUDF " & s & "  ")
            '                Next
            '                oApplication.SBO_Application.StatusBar.SetText("UDF's updated Successfully", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            '                'oForm.Freeze(False)
            '            Catch ex As Exception
            '                oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
            '                'Finally
            '                '    oForm.Freeze(False)
            '            End Try
            '    End Select
            'End If

            '########################## Alert Window #########################
            'If pVal.FormType = frm_Alert And pVal.EventType = SAPbouiCOM.BoEventTypes.et_MATRIX_LINK_PRESSED Then
            '    If Not _Collection.ContainsKey(FormUID) Then
            '        oItemObject = New clsMessages
            '        oItemObject.FrmUID = FormUID
            '        _Collection.Add(FormUID, oItemObject)
            '    End If
            'End If
            '########## Code For LookUp Forms #################################
            If _Collection.ContainsKey(FormUID) Then
                oItemObject = _Collection.Item(FormUID)
                If oItemObject.IsLookUpOpen And pVal.BeforeAction = True Then
                    _SBO_Application.Forms.Item(oItemObject.LookUpFormUID).Select()
                    BubbleEvent = False
                    Exit Sub
                End If
                _Collection.Item(FormUID).ItemEvent(FormUID, pVal, BubbleEvent)
            End If

            If pVal.EventType = SAPbouiCOM.BoEventTypes.et_FORM_UNLOAD And pVal.BeforeAction = False Then
                If _LookUpCollection.ContainsKey(FormUID) Then
                    oItemObject = _Collection.Item(_LookUpCollection.Item(FormUID))
                    If Not oItemObject Is Nothing Then
                        oItemObject.IsLookUpOpen = False
                    End If
                    _LookUpCollection.Remove(FormUID)
                End If

                If _Collection.ContainsKey(FormUID) Then
                    _Collection.Item(FormUID) = Nothing
                    _Collection.Remove(FormUID)
                End If
            End If
        Catch ex As Exception
            Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try
    End Sub
#End Region

#Region "Form Data Events"
    Private Sub SBO_Application_FormDataEvent(ByRef BusinessObjectInfo As SAPbouiCOM.BusinessObjectInfo, ByRef BubbleEvent As Boolean) Handles _SBO_Application.FormDataEvent
        Try


            If BusinessObjectInfo.BeforeAction = False Then
                BubbleEvent = False
                Select Case BusinessObjectInfo.Type
                    'Case "AIS_VARS"
                    '    _FormUID = oApplication.SBO_Application.Forms.ActiveForm.UniqueID
                    '    If _Collection.ContainsKey(_FormUID) Then
                    '        oFormObject = _Collection.Item(_FormUID)
                    '        oFormObject.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                    '    End If

                    'Case "2"
                    '    _FormUID = oApplication.SBO_Application.Forms.GetForm(BusinessObjectInfo.FormTypeEx, 0).UniqueID
                    '    If _Collection.ContainsKey(_FormUID) And BusinessObjectInfo.FormTypeEx = "134" Then
                    '        oFormObject = _Collection.Item(_FormUID)
                    '        oFormObject.FormDataEvent(BusinessObjectInfo, BubbleEvent)
                    '    End If
                End Select
            End If
        Catch ex As Exception
            Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        Finally
            oFormObject = Nothing
        End Try
    End Sub

#End Region

#Region "Application Event"
    Private Sub SBO_Application_AppEvent(ByVal EventType As SAPbouiCOM.BoAppEventTypes) Handles _SBO_Application.AppEvent
        Try

            Select Case EventType
                Case SAPbouiCOM.BoAppEventTypes.aet_ShutDown, SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition, SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged
                    '_Utilities.AddRemoveMenus("RemoveMenus.xml")
                    CloseApp()
            End Select

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Termination Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
        End Try
    End Sub
#End Region

#Region "Close Application"
    Private Sub CloseApp()
        Try
            If Not _SBO_Application Is Nothing Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(_SBO_Application)
            End If

            If Not _Company Is Nothing Then
                If _Company.Connected Then
                    _Company.Disconnect()
                End If
                System.Runtime.InteropServices.Marshal.ReleaseComObject(_Company)
            End If

            _Utilities = Nothing
            _Collection = Nothing
            _LookUpCollection = Nothing
            _Company = Nothing

            ThreadClose.Sleep(10)
            System.Windows.Forms.Application.Exit()
        Catch ex As Exception
            'Throw ex
        Finally
            oApplication = Nothing
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try
    End Sub
#End Region

#Region "Set Application"
    Private Sub SetApplication()
        Dim SboGuiApi As SAPbouiCOM.SboGuiApi
        Dim sConnectionString As String

        Try
            If Environment.GetCommandLineArgs.Length > 1 Then
                sConnectionString = Environment.GetCommandLineArgs.GetValue(1)
                SboGuiApi = New SAPbouiCOM.SboGuiApi
                SboGuiApi.Connect(sConnectionString)
                _SBO_Application = SboGuiApi.GetApplication()
            Else

                Throw New Exception("Connection string missing.")
            End If

        Catch ex As Exception
            Throw ex
        Finally
            SboGuiApi = Nothing
        End Try
    End Sub
#End Region

#Region "Finalize"
    Protected Overrides Sub Finalize()
        Try
            MyBase.Finalize()
            CloseApp()

            oMenuObject = Nothing
            oItemObject = Nothing
            oSystemForms = Nothing

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Addon Termination Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
        Finally
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try
    End Sub
#End Region

End Class

