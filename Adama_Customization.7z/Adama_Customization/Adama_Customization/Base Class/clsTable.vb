
Public NotInheritable Class clsTable

#Region "Private Functions"

#Region "Add Tables"

    Private Sub AddTables(ByVal strTab As String, ByVal strDesc As String, ByVal nType As SAPbobsCOM.BoUTBTableType)
        Dim oUserTablesMD As SAPbobsCOM.UserTablesMD
        Try

            oUserTablesMD = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables)
            'Adding Table
            If Not oUserTablesMD.GetByKey(strTab) Then
                oUserTablesMD.TableName = strTab
                oUserTablesMD.TableDescription = strDesc
                oUserTablesMD.TableType = nType
                If oUserTablesMD.Add <> 0 Then
                    Throw New Exception(oApplication.Company.GetLastErrorDescription)
                End If
            End If
        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        Finally
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserTablesMD)
            oUserTablesMD = Nothing
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try
    End Sub

#End Region

#Region "Add Fields"
    Private Sub AddFields(ByVal strTab As String, _
                         ByVal strCol As String, _
                             ByVal strDesc As String, _
                                 ByVal nType As SAPbobsCOM.BoFieldTypes, _
                                     Optional ByVal i As Integer = 0, _
                                         Optional ByVal nEditSize As Integer = 10, _
                                             Optional ByVal nSubType As SAPbobsCOM.BoFldSubTypes = 0, _
                                                 Optional ByVal Mandatory As SAPbobsCOM.BoYesNoEnum = SAPbobsCOM.BoYesNoEnum.tNO, _
                                                    Optional ByVal ValidValue As Integer = 0, Optional ByVal LinkedTable As String = "", Optional ByVal LinkedUDO As String = "")
        Dim oUserFieldMD As SAPbobsCOM.UserFieldsMD
        Try
            If strTab = "OPLN" Or strTab = "INV1" Or strTab = "OCRD" Or strTab = "ODSC" Or strTab = "OADM" Or strTab = "OINV" Then
                If Not IsColumnExists(strTab, strCol) Then

                    oUserFieldMD = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields)

                    oUserFieldMD.Description = strDesc
                    oUserFieldMD.Name = strCol
                    oUserFieldMD.Type = nType
                    oUserFieldMD.SubType = nSubType
                    oUserFieldMD.TableName = strTab
                    oUserFieldMD.EditSize = nEditSize
                    oUserFieldMD.Mandatory = Mandatory
                    If LinkedTable <> "" Then
                        oUserFieldMD.LinkedTable = LinkedTable
                    End If
                    If LinkedUDO <> "" Then
                        oUserFieldMD.LinkedUDO = LinkedUDO
                    End If

                    If ValidValue = 1 Then

                        oUserFieldMD.ValidValues.Value = "None"
                        oUserFieldMD.ValidValues.Description = "None"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "ACH"
                        oUserFieldMD.ValidValues.Description = "Bank Account"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "CC"
                        oUserFieldMD.ValidValues.Description = "Credit Card"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "None"

                    End If
                    If ValidValue = 2 Then

                        oUserFieldMD.ValidValues.Value = "Round Up"
                        oUserFieldMD.ValidValues.Description = "Round Up"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "Round Down"
                        oUserFieldMD.ValidValues.Description = "Round Down"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "None"
                        oUserFieldMD.ValidValues.Description = "None"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "None"

                    End If

                    If ValidValue = 3 Then

                        oUserFieldMD.ValidValues.Value = "Checking"
                        oUserFieldMD.ValidValues.Description = "Checking"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "Saving"
                        oUserFieldMD.ValidValues.Description = "Saving"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "Current"
                        oUserFieldMD.ValidValues.Description = "Current"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "Saving"

                    End If

                    If ValidValue = 4 Then
                        oUserFieldMD.DefaultValue = "Lewes Utilities"
                    End If

                    If ValidValue = 5 Then
                        oUserFieldMD.ValidValues.Value = "Y"
                        oUserFieldMD.ValidValues.Description = "Yes"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "N"
                        oUserFieldMD.ValidValues.Description = "No"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "N"
                    End If

                    If ValidValue = 6 Then
                        oUserFieldMD.ValidValues.Value = "VISA"
                        oUserFieldMD.ValidValues.Description = "VISA"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "MASTER"
                        oUserFieldMD.ValidValues.Description = "MASTER"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "Discover AMEX"
                        oUserFieldMD.ValidValues.Description = "Discover AMEX"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "VISA"
                    End If

                    If oUserFieldMD.Add <> 0 Then
                        Throw New Exception(oApplication.Company.GetLastErrorDescription)
                    End If

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldMD)

                End If
            Else
                oUserFieldMD = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields)
                If Not oUserFieldMD.GetByKey("@" & strTab, i) Then
                    oUserFieldMD.Description = strDesc
                    oUserFieldMD.Name = strCol
                    oUserFieldMD.Type = nType
                    oUserFieldMD.SubType = nSubType
                    oUserFieldMD.TableName = strTab
                    oUserFieldMD.EditSize = nEditSize
                    oUserFieldMD.Mandatory = Mandatory
                    If ValidValue = 1 Then


                        oUserFieldMD.ValidValues.Value = "N"
                        oUserFieldMD.ValidValues.Description = "NO"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "Y"
                        oUserFieldMD.ValidValues.Description = "YES"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "N"

                    End If
                    If ValidValue = 2 Then


                        oUserFieldMD.ValidValues.Value = "O"
                        oUserFieldMD.ValidValues.Description = "Open"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "P"
                        oUserFieldMD.ValidValues.Description = "Pending"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.ValidValues.Value = "C"
                        oUserFieldMD.ValidValues.Description = "Closed"
                        oUserFieldMD.ValidValues.Add()
                        oUserFieldMD.DefaultValue = "O"

                    End If

                    If oUserFieldMD.Add <> 0 Then
                        Throw New Exception(oApplication.Company.GetLastErrorDescription)
                    End If

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserFieldMD)

                End If
            End If
        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        Finally
            oUserFieldMD = Nothing
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try
    End Sub

#End Region

#Region "Check Whether Column Exsists or not"

    Private Function IsColumnExists(ByVal Table As String, ByVal Column As String) As Boolean
        Dim oRecordSet As SAPbobsCOM.Recordset

        Try
            strSQL = "SELECT COUNT(*) FROM CUFD WHERE TableID = '" & Table & "' AND AliasID = '" & Column & "'"
            oRecordSet = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            oRecordSet.DoQuery(strSQL)

            If oRecordSet.Fields.Item(0).Value = 0 Then
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        Finally
            oRecordSet = Nothing
            GC.Collect()
        End Try
    End Function

#End Region

#Region "Add Unique Key"
    Private Sub AddKey(ByVal strTab As String, ByVal strColumn As String, ByVal strKey As String, ByVal i As Integer)
        Dim oUserKeysMD As SAPbobsCOM.UserKeysMD

        Try
            '// The meta-data object must be initialized with a
            '// regular UserKeys object
            oUserKeysMD = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserKeys)

            If Not oUserKeysMD.GetByKey("@" & strTab, i) Then

                '// Set the table name and the key name
                oUserKeysMD.TableName = strTab
                oUserKeysMD.KeyName = strKey

                '// Set the column's alias
                oUserKeysMD.Elements.ColumnAlias = strColumn
                oUserKeysMD.Elements.Add()

                '// Determine whether the key is unique or not
                oUserKeysMD.Unique = SAPbobsCOM.BoYesNoEnum.tYES

                '// Add the key
                If oUserKeysMD.Add <> 0 Then
                    Throw New Exception(oApplication.Company.GetLastErrorDescription)
                End If

            End If

        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)

        Finally
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserKeysMD)
            oUserKeysMD = Nothing
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Try

    End Sub

#End Region

#Region "Add UDO"

    Private Sub AddUDO(ByVal strUDO As String, ByVal strDesc As String, ByVal strTable As String, _
                                    Optional ByVal sFind1 As String = "", Optional ByVal sFind2 As String = "", Optional ByVal sFind3 As String = "", _
                                            Optional ByVal strChildTbl As String = "", Optional ByVal strChildTbl2 As String = "", Optional ByVal nObjectType As SAPbobsCOM.BoUDOObjType = SAPbobsCOM.BoUDOObjType.boud_Document, Optional ByVal CanLog As Boolean = False)

        Dim oUserObjectMD As SAPbobsCOM.UserObjectsMD
        Try
            oUserObjectMD = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)
            If oUserObjectMD.GetByKey(strUDO) = 0 Then
                oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES
                oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES
                
                oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES
                oUserObjectMD.EnableEnhancedForm = SAPbobsCOM.BoYesNoEnum.tYES


                oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES

                If sFind1 <> "" Then
                    oUserObjectMD.FindColumns.ColumnAlias = sFind1
                    oUserObjectMD.FindColumns.Add()
                End If
                If sFind2 <> "" Then
                    oUserObjectMD.FindColumns.SetCurrentLine(1)
                    oUserObjectMD.FindColumns.ColumnAlias = sFind2
                    oUserObjectMD.FindColumns.Add()
                End If
                If sFind3 <> "" Then
                    oUserObjectMD.FindColumns.SetCurrentLine(2)
                    oUserObjectMD.FindColumns.ColumnAlias = sFind3
                    oUserObjectMD.FindColumns.Add()
                End If
                If CanLog = True Then
                    oUserObjectMD.CanLog = SAPbobsCOM.BoYesNoEnum.tYES
                ElseIf CanLog = False Then
                    oUserObjectMD.CanLog = SAPbobsCOM.BoYesNoEnum.tNO
                End If
                'oUserObjectMD.LogTableName = ""
                oUserObjectMD.CanYearTransfer = SAPbobsCOM.BoYesNoEnum.tNO
                oUserObjectMD.ExtensionName = ""

                If strChildTbl <> "" Then
                    oUserObjectMD.ChildTables.TableName = strChildTbl
                    oUserObjectMD.ChildTables.Add()
                End If

                If strChildTbl2 <> "" Then
                    oUserObjectMD.ChildTables.TableName = strChildTbl2
                    oUserObjectMD.ChildTables.Add()
                End If

                If strTable = "BOS_OTRN" Then
                    oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES
                Else
                    oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tNO
                End If

                oUserObjectMD.Code = strUDO
                oUserObjectMD.Name = strDesc
                oUserObjectMD.ObjectType = nObjectType
                oUserObjectMD.TableName = strTable

                If oUserObjectMD.Add() <> 0 Then
                    Throw New Exception(oApplication.Company.GetLastErrorDescription)
                End If
            End If

        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)

        Finally
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD)
            oUserObjectMD = Nothing
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try

    End Sub
#End Region

#End Region

#Region "Public Functions"

#Region "Create Tables "
    Public Sub CreateTables()
        Dim oProgressBar As SAPbouiCOM.ProgressBar
        Try

            'oProgressBar = oApplication.SBO_Application.StatusBar.CreateProgressBar("Initializing Database...", 8, False)
            'oProgressBar.Value = 0

            'oApplication.Company.StartTransaction()
            oApplication.SBO_Application.StatusBar.SetText("Initializing Settings... Adama Customization", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            '''----User Defined Fields
            'oProgressBar.Text = "Initializing Settings... Utility Billing - Payment"

            
            AddTables("BOSBECONFIG", "Bank Extract Conf", SAPbobsCOM.BoUTBTableType.bott_MasterData)
            AddFields("BOSBECONFIG", "ACTIVE", "ACTIVE", SAPbobsCOM.BoFieldTypes.db_Alpha, 0, 1, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 1, "", "")
            AddFields("BOSBECONFIG", "OUTDIR", "OUTDIR", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, 254, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBECONFIG", "ARCHDIR", "ARCHDIR", SAPbobsCOM.BoFieldTypes.db_Alpha, 2, 254, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBECONFIG", "FILENAME", "FILENAME", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, 100, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBECONFIG", "EXT", "EXT", SAPbobsCOM.BoFieldTypes.db_Alpha, 4, 10, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBECONFIG", "NEWVIEW", "NEWVIEW", SAPbobsCOM.BoFieldTypes.db_Alpha, 5, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBECONFIG", "HISTVIEW", "HISTVIEW", SAPbobsCOM.BoFieldTypes.db_Alpha, 6, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBECONFIG", "EXTLOGIC", "EXTLOGIC", SAPbobsCOM.BoFieldTypes.db_Alpha, 7, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            
            '---- User Defined Object's
            CreateUDO()

            AddFields("OVPM", "BOSBEDTM", "Bank Extract Date Time", SAPbobsCOM.BoFieldTypes.db_Alpha, 0, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")


            AddTables("BOSBELOG", "Bank Extract Log", SAPbobsCOM.BoUTBTableType.bott_NoObject)
            AddFields("BOSBELOG", "ACTIVE", "ACTIVE", SAPbobsCOM.BoFieldTypes.db_Alpha, 0, 1, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 1, "", "")
            AddFields("BOSBELOG", "ProcID", "ProcID", SAPbobsCOM.BoFieldTypes.db_Alpha, 1, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "ProcDTM", "ProcDTM", SAPbobsCOM.BoFieldTypes.db_Date, 2, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "ExportCode", "ExportCode", SAPbobsCOM.BoFieldTypes.db_Alpha, 3, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "UserID", "UserID", SAPbobsCOM.BoFieldTypes.db_Alpha, 4, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "BankAcct", "BankAcct", SAPbobsCOM.BoFieldTypes.db_Alpha, 5, 20, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "OUTDIR", "OUTDIR", SAPbobsCOM.BoFieldTypes.db_Alpha, 6, 254, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "ARCHDIR", "ARCHDIR", SAPbobsCOM.BoFieldTypes.db_Alpha, 7, 254, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "FILENAME", "FILENAME", SAPbobsCOM.BoFieldTypes.db_Alpha, 8, 100, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            AddFields("BOSBELOG", "PayPrcd", "PayPrcd", SAPbobsCOM.BoFieldTypes.db_Memo, 9, 254, SAPbobsCOM.BoFldSubTypes.st_None, SAPbobsCOM.BoYesNoEnum.tNO, 0, "", "")
            
            
            'If oApplication.Company.InTransaction() Then
            '    oApplication.Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit)
            'End If

        Catch ex As Exception
            'If oApplication.Company.InTransaction() Then
            '    oApplication.Company.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack)
            'End If
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        Finally
            'oProgressBar.Stop()
            'System.Runtime.InteropServices.Marshal.ReleaseComObject(oProgressBar)
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Try
    End Sub
#End Region

#Region "Create UDO"

    Public Sub CreateUDO()
        Try
            AddUDO("BOS_BECONFIG", "Bank Extract Config", "BOSBECONFIG", "Code", "Name", "U_ACTIVE", "", "", SAPbobsCOM.BoUDOObjType.boud_MasterData, True)
        Catch ex As Exception
            oApplication.SBO_Application.SetStatusBarMessage(ex.Message)
        End Try
    End Sub

#End Region

#End Region

End Class


