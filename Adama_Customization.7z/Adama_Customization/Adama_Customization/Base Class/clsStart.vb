
Public Class clsStart

    Shared Sub Main()
        Try
            Try
                oApplication = New clsListener
                oApplication.Utilities.Connect()
                oApplication.Utilities.SetFilters()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly)
                Exit Sub
            End Try
            'oApplication.Utilities.CreateTables()
            oApplication.SBO_Application.StatusBar.SetText("Adama Customization has been connected to : " & oApplication.Company.CompanyName, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
           System.Windows.Forms.Application.Run()

        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub



End Class


