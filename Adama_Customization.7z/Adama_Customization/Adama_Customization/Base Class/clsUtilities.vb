
Public Class clsUtilities

    Private FormNum As Integer
    Public oFilters As SAPbouiCOM.EventFilters
    Public oFilter As SAPbouiCOM.EventFilter
    Dim NCMTables As SAPbobsCOM.UserTablesMD
    Dim NCMFields As SAPbobsCOM.UserFieldsMD

    Public Sub New()
        MyBase.New()
        FormNum = 1
    End Sub

#Region "Connect to Company"
    Public Sub Connect()
        Dim strCookie As String
        Dim strConnectionContext As String

        Try
            strCookie = oApplication.Company.GetContextCookie
            strConnectionContext = oApplication.SBO_Application.Company.GetConnectionContext(strCookie)

            If oApplication.Company.SetSboLoginContext(strConnectionContext) <> 0 Then
                Throw New Exception("Wrong login credentials.")
            End If

            'Open a connection to company
            Dim ret As Integer
            ret = oApplication.Company.Connect
            If ret <> 0 Then
                'MsgBox(oApplication.Company.GetLastErrorDescription)
                'If oApplication.Company.Connect() <> 0 Then
                MsgBox(oApplication.Company.GetLastErrorDescription)
                'End If
            End If
            '************************Table & Menu Creation Code****************************************************
            oApplication.SBO_Application.StatusBar.SetText("Please wait......Connecting Adama Customization Add-On", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            CallCreateTable()
            CallAddUDO()
            CreateMenu()
            CreateFMS()
            AssignFMS("BankExtract", "20", "", "Bank Extract Log")
            'AssignFMS("ApproveOrd", "7", "", "Reason Code")
            'AssignFMS("ApproveOrd", "8", "", "Credit Manager")

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Add/Remove Menus "
    Public Sub AddRemoveMenus(ByVal sFileName As String)
        Dim oXMLDoc As New Xml.XmlDocument
        Dim sFilePath As String
        Try
            sFilePath = getApplicationPath() & "\XML Files\" & sFileName
            oXMLDoc.Load(sFilePath)
            oApplication.SBO_Application.LoadBatchActions(oXMLDoc.InnerXml)
        Catch ex As Exception
            Throw ex
        Finally
            oXMLDoc = Nothing
        End Try
    End Sub
#End Region

#Region "loadXML"
    Public Function loadXML(ByVal XMLFile)
        Dim oXML As System.Xml.XmlDocument
        Dim objFormCreationParams As SAPbouiCOM.FormCreationParams
        Dim stream As System.IO.Stream = Me.GetType().Assembly.GetManifestResourceStream(XMLFile)
        Try
            oXML = New System.Xml.XmlDocument

            Debug.WriteLine("Loading XML Batch from embedded resource:" + XMLFile)
            'thisAssembly = [Assembly]
            'rgbxml = thisAssembly.GetManifestResourceStream(XMLFile)
            '[Assembly](thisAssembly = [Assembly].GetExecutingAssembly())
            oXML.Load(stream)
            oApplication.SBO_Application.LoadBatchActions(XMLFile)
            'objFormCreationParams = (oApplication.SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_FormCreationParams))
            'objFormCreationParams.XmlData = oXML.InnerXml
            'objFormCreationParams.FormType = FormType
            'objFormCreationParams.UniqueID = FormUID
            'Return objApplication.Forms.AddEx(objFormCreationParams)
        Catch ex As Exception
            'Throw ex
            MsgBox(ex.Message)
        End Try
    End Function
#End Region

#Region "Load XML File "
    Private Function LoadXMLFiles(ByVal sFileName As String) As String
        Dim oXmlDoc As Xml.XmlDocument
        Dim oXNode As Xml.XmlNode
        Dim oAttr As Xml.XmlAttribute
        Dim sPath As String
        Dim FrmUID As String
        Try
            oXmlDoc = New Xml.XmlDocument

            sPath = getApplicationPath() & "\XML Files\" & sFileName

            oXmlDoc.Load(sPath)
            oXNode = oXmlDoc.GetElementsByTagName("form").Item(0)
            oAttr = oXNode.Attributes.GetNamedItem("uid")
            oAttr.Value = oAttr.Value & FormNum
            FormNum = FormNum + 1
            oApplication.SBO_Application.LoadBatchActions(oXmlDoc.InnerXml)
            FrmUID = oAttr.Value

            Return FrmUID

        Catch ex As Exception
            Throw ex
        Finally
            oXmlDoc = Nothing
        End Try
    End Function
#End Region

#Region "Load Forms"
    Public Sub LoadForm(ByRef oObject As Object, ByVal XmlFile As String)
        Try

            oObject.FrmUID = LoadXMLFiles(XmlFile)
            oObject.Form = oApplication.SBO_Application.Forms.Item(oObject.FrmUID)
            If Not oApplication.Collection.ContainsKey(oObject.FrmUID) Then
                oApplication.Collection.Add(oObject.FrmUID, oObject)
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Get MaxCode"
    Public Function getMaxCode(ByVal sTable As String, ByVal sColumn As String, Optional ByVal bFormat As Boolean = True) As String
        Dim oRS As SAPbobsCOM.Recordset
        Dim MaxCode As Integer
        Dim sCode As String
        Dim strSQL As String
        Try
            strSQL = "SELECT MAX(CAST(ISNULL(" & sColumn & ",0) AS Numeric)) FROM [" & sTable & "]"
            ExecuteSQL(oRS, strSQL)

            If Convert.ToString(oRS.Fields.Item(0).Value).Length > 0 Then
                MaxCode = oRS.Fields.Item(0).Value + 1
            Else
                MaxCode = 1
            End If
            If bFormat = True Then
                sCode = Format(MaxCode, "00000000")
                Return sCode
            Else
                Return MaxCode
            End If

        Catch ex As Exception
            Throw ex
        Finally
            oRS = Nothing
        End Try
    End Function
#End Region

#Region "Status Message"
    Public Sub Message(ByVal sMessage As String, ByVal StatusType As SAPbouiCOM.BoStatusBarMessageType)
        oApplication.SBO_Application.StatusBar.SetText(sMessage, SAPbouiCOM.BoMessageTime.bmt_Short, StatusType)
    End Sub
#End Region

#Region "Create Tables"
    Public Sub CreateTables()
        Dim oCreateTable As clsTable
        Try
            oCreateTable = New clsTable
            oCreateTable.CreateTables()
        Catch ex As Exception
            Throw ex
        Finally
            oCreateTable = Nothing
        End Try
    End Sub
#End Region

#Region "Execute Query"
    Public Sub ExecuteSQL(ByRef oRecordSet As SAPbobsCOM.Recordset, ByVal SQL As String)
        Try
            If oRecordSet Is Nothing Then
                oRecordSet = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            End If

            oRecordSet.DoQuery(SQL)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Get Application path"
    Public Function getApplicationPath() As String
        'Return IO.Directory.GetParent(Application.StartupPath).ToString
        Return Application.StartupPath.ToString
    End Function
#End Region

#Region "Get Linked Object Type"
    Public Function getLinkedObjectType(ByVal Type As SAPbouiCOM.BoLinkedObject) As String
        Return CType(Type, String)
    End Function

#End Region

#Region "Date Manipulation"

#Region "Convert SBO Date to System Date"
    '********************************************************************
    'Type		            :   Public Procedure     
    'Name               	:	ConvertStrToDate
    'Parameter          	:   ByVal oDate As String, ByVal strFormat As String
    'Return Value       	:	
    'Author             	:	Manu
    'Created Date       	:	07/12/05
    'Last Modified By	    :	
    'Modified Date        	:	
    'Purpose             	:	To convert Date according to current culture info
    '********************************************************************
    Public Function ConvertStrToDate(ByVal strDate As String, ByVal strFormat As String) As DateTime
        Try
            Dim oDate As DateTime
            Dim ci As New System.Globalization.CultureInfo("en-GB", False)
            Dim newCi As System.Globalization.CultureInfo = CType(ci.Clone(), System.Globalization.CultureInfo)

            System.Threading.Thread.CurrentThread.CurrentCulture = newCi
            oDate = oDate.ParseExact(strDate, strFormat, ci.DateTimeFormat)

            Return oDate
        Catch ex As Exception
            Throw ex
        End Try

    End Function
#End Region

#Region " Get SBO Date Format in String (ddmmyyyy)"
    '********************************************************************
    'Type		            :   Public Procedure     
    'Name               	:	StrSBODateFormat
    'Parameter          	:   none
    'Return Value       	:	
    'Author             	:	Manu
    'Created Date       	:	
    'Last Modified By	    :	
    'Modified Date        	:	
    'Purpose             	:	To get date Format(ddmmyy value) as applicable to SBO
    '********************************************************************
    Public Function StrSBODateFormat() As String
        Try
            Dim rsDate As SAPbobsCOM.Recordset
            Dim strsql As String, GetDateFormat As String
            Dim DateSep As Char

            strsql = "Select DateFormat,DateSep from OADM"
            rsDate = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            rsDate.DoQuery(strsql)
            DateSep = rsDate.Fields.Item(1).Value

            Select Case rsDate.Fields.Item(0).Value
                Case 0
                    GetDateFormat = "dd" & DateSep & "MM" & DateSep & "yy"
                Case 1
                    GetDateFormat = "dd" & DateSep & "MM" & DateSep & "yyyy"
                Case 2
                    GetDateFormat = "MM" & DateSep & "dd" & DateSep & "yy"
                Case 3
                    GetDateFormat = "MM" & DateSep & "dd" & DateSep & "yyyy"
                Case 4
                    GetDateFormat = "yyyy" & DateSep & "dd" & DateSep & "MM"
                Case 5
                    GetDateFormat = "dd" & DateSep & "MMM" & DateSep & "yyyy"
            End Select
            Return GetDateFormat

        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region

#Region "Get SBO date Format in Number"
    '********************************************************************
    'Type		            :   Public Procedure     
    'Name               	:	IntSBODateFormat
    'Parameter          	:   none
    'Return Value       	:	
    'Author             	:	Manu
    'Created Date       	:	
    'Last Modified By	    :	
    'Modified Date        	:	
    'Purpose             	:	To get date Format(integer value) as applicable to SBO
    '********************************************************************
    Public Function NumSBODateFormat() As String
        Try
            Dim rsDate As SAPbobsCOM.Recordset
            Dim strsql As String
            Dim DateSep As Char

            strsql = "Select DateFormat,DateSep from OADM"
            rsDate = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset)
            rsDate.DoQuery(strsql)
            DateSep = rsDate.Fields.Item(1).Value

            Select Case rsDate.Fields.Item(0).Value
                Case 0
                    NumSBODateFormat = 3
                Case 1
                    NumSBODateFormat = 103
                Case 2
                    NumSBODateFormat = 1
                Case 3
                    NumSBODateFormat = 120
                Case 4
                    NumSBODateFormat = 126
                Case 5
                    NumSBODateFormat = 130
            End Select
            Return NumSBODateFormat

        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region

#End Region

#Region "GetPrice Double"
    Public Function GetPrice(ByVal sPrice As String) As Double
        Dim strlen As Integer
        Dim i As Integer
        Dim strPrice As String
        Dim dblPrice As Double
        strlen = sPrice.Length
        strPrice = ""
        i = 0
        Try
            While i < strlen
                If (Asc(sPrice.Chars(i)) >= 48 And Asc(sPrice.Chars(i)) <= 57) Or Asc(sPrice.Chars(i)) = 46 Or Asc(sPrice.Chars(i)) = 44 Then
                    strPrice = strPrice & sPrice.Chars(i)
                End If
                i = i + 1
            End While
            If strPrice <> "" Then
                dblPrice = Convert.ToDouble(strPrice)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        GetPrice = dblPrice
    End Function
#End Region

#Region "ValidateDate"
    Public Function ValidateDate(ByVal strPDate As String, ByVal oDate As DateTime) As Boolean
        Try
            Dim dt As String
            Dim oRecordset As SAPbobsCOM.Recordset
            dt = Convert.ToDateTime(oApplication.SBO_Application.Company.ServerDate).ToString("yyyyMMdd")
            If oDate.ToString("yyyyMMdd") > Convert.ToDateTime(oApplication.SBO_Application.Company.ServerDate).ToString("yyyyMMdd") Then
                oApplication.SBO_Application.SetStatusBarMessage("Date Later Than System Date", SAPbouiCOM.BoMessageTime.bmt_Short, True)
                Return True
                Exit Function
            End If

            strSQL = " Select Case when '" & strPDate & "'" & _
                  " between (Select F_RefDate from OFPR where  '" & dt & "' Between" & _
                  " F_RefDate and T_RefDate )and (Select T_RefDate from OFPR Where  '" & dt & "' Between" & _
                  " F_RefDate and T_RefDate) Then 'True' else  'False' end as Result"

            oApplication.Utilities.ExecuteSQL(oRecordset, strSQL)
            If oRecordset.RecordCount > 0 Then
                If oRecordset.Fields.Item("Result").Value = True Then
                    Return False
                    Exit Function
                Else
                    oApplication.SBO_Application.SetStatusBarMessage("Date does not Fall in the Current Posting Period", SAPbouiCOM.BoMessageTime.bmt_Short)
                    Return True
                    Exit Function
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function

#End Region

#Region "ValidateWH"
    Public Function ValidateWH(ByVal sWH As String, ByVal Series As String) As Boolean
        Try

            If Series.StartsWith("TR") = True And sWH.StartsWith("TR") = True Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region

#Region "ValidateItem"
    Public Function ValidateItem(ByVal sItem As String) As Boolean
        Try
            Dim oItem As SAPbobsCOM.Items
            oItem = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oItems)
            If oItem.GetByKey(sItem) = True Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region

#Region "Validate Item Group"
    Public Function ValidateItemGroup(ByVal sItemCode As String) As Boolean

        Dim oRS As SAPbobsCOM.Recordset
        Try
            strSQL = " SElect OITB.ItmsGrpNam from OITM inner join OITB on " & _
                     " OITM.ItmsGrpCod = OITB.ItmsGrpCod where OITM.ItemCode = '" & sItemCode & "'"
            oApplication.Utilities.ExecuteSQL(oRS, strSQL)
            If oRS.RecordCount > 0 Then
                If String.Compare(oRS.Fields.Item(0).Value, "Ready Made Wind.&Do.") = 0 Then
                    Return True
                    Exit Function
                End If
            End If
            Return False
        Catch ex As Exception
            Throw ex
        Finally
            oRS = Nothing
        End Try

    End Function
#End Region

#Region "ValidateARInvoiceNo"
    Public Function ValidateARInvoiceNo(ByVal sInvoiceNo As String) As Boolean
        Try
            Dim oInvoice As SAPbobsCOM.Documents
            oInvoice = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oInvoices)
            If oInvoice.GetByKey(sInvoiceNo) = True Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function
#End Region

#Region "Negative Form Activation"
    Sub NegFormActivate()
        '############### Call this SUB on Form Resize event in case False ############
        Dim omenu As SAPbouiCOM.MenuItem
        omenu = oApplication.SBO_Application.Menus.Item("6913")
        If omenu.Checked = False Then
            oApplication.SBO_Application.ActivateMenuItem("6913")
        End If
    End Sub
#End Region

#Region "Add Button on Grid"
    'Sub addbutton()
    '    Dim oItem1, oItem As SAPbouiCOM.Item
    '    Dim oform As SAPbouiCOM.Form
    '    Dim obutton As SAPbouiCOM.Button
    '    oform = oApplication.SBO_Application.Forms.ActiveForm
    '    oItem = oform.Items.Item("MyGrid")
    '    oItem1 = oform.Items.Add("view", SAPbouiCOM.BoFormItemTypes.it_BUTTON)
    '    oItem1.Top = oItem.Top + oItem.Height + 10
    '    oItem1.Left = 15
    '    oItem1.Width = 100
    '    obutton = oItem1.Specific
    '    obutton.Caption = "Normal Layout"
    'End Sub
#End Region

#Region "Number_to_Text"
    Function Number_to_Text(ByVal number)
        Try
            Dim arrUnit(19), arrTens(8), arrHundred(2) As String
            Dim strTemp As String
            arrUnit(0) = ""
            arrUnit(1) = "One"
            arrUnit(2) = "Two"
            arrUnit(3) = "Three"
            arrUnit(4) = "Four"
            arrUnit(5) = "Five"
            arrUnit(6) = "Six"
            arrUnit(7) = "Seven"
            arrUnit(8) = "Eigth"
            arrUnit(9) = "Nine"
            arrUnit(10) = "Ten"
            arrUnit(11) = "Eleven"
            arrUnit(12) = "Twelve"
            arrUnit(13) = "Thirteen"
            arrUnit(14) = "Fourteen"
            arrUnit(15) = "Fifteen"
            arrUnit(16) = "Sixteen"
            arrUnit(17) = "Seventeen"
            arrUnit(18) = "Eighteen"
            arrUnit(19) = "Nineteen"
            arrTens(0) = ""
            arrTens(1) = "Twenty"
            arrTens(2) = "Thirty"
            arrTens(3) = "Forty"
            arrTens(4) = "Fifty"
            arrTens(5) = "Sixty"
            arrTens(6) = "Seventy"
            arrTens(7) = "Eighty"
            arrTens(8) = "Ninety"
            arrHundred(0) = "Hundred"

            If number > 0 And number <= 19 Then
                Number_to_Text = arrUnit(number)
            End If

            If number >= 20 And number <= 99 Then
                Number_to_Text = arrTens(Mid(number, 1, 1) - 1) & " " & arrUnit(Mid(number, 2, 1))
            End If

            If number >= 100 And number <= 999 Then
                strTemp = arrUnit(Mid(number, 1, 1)) & " " & arrHundred(0)
                If Mid(number, 2, 2) = 0 Then
                    Number_to_Text = strTemp
                    ' & " and " & arrUnit(mid(number, 3, 1)) 
                End If

                If Mid(number, 2, 2) >= 1 And Mid(number, 2, 2) <= 19 Then
                    'Number_to_Text = strTemp & " and " & arrUnit(Mid(number, 2, 2))
                    Number_to_Text = strTemp & " " & arrUnit(Mid(number, 2, 2))
                End If

                If Mid(number, 2, 2) >= 20 Then
                    'Number_to_Text = strTemp & " and " & arrTens(Mid(number, 2, 1) - 1) & " " & arrUnit(Mid(number, 3, 1))
                    Number_to_Text = strTemp & " " & arrTens(Mid(number, 2, 1) - 1) & " " & arrUnit(Mid(number, 3, 1))
                End If
            End If
        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Function
#End Region

#Region "AmountInWords"
    Public Function AmountInWords(ByVal M_Amt As Double, Optional ByVal Maincur_code As String = "Rupees", Optional ByVal FractCur_code As String = "Paise", Optional ByVal separationChar As String = "AND") As String
        Try
            Dim M_Amount_US As String
            Dim PadString As New String("0", 12)
            Dim num As String
            num = PadString.Concat(PadString, Trim(Str(M_Amt)))
            M_Amount_US = Right$(num, 14)
            ' PadL(Trim(str(M_Amt)), 14, "0") 
            Dim Hunds As Long
            Dim Thous As Long
            Dim Crores As Long
            Dim Lakhs As Long
            Dim Decs As Long
            If Mid(M_Amount_US, 12, 1) = "." Then
            ElseIf Mid(M_Amount_US, 13, 1) = "." Then
                M_Amount_US = Trim(Mid(M_Amount_US, 2)) + "0"
            Else
                M_Amount_US = Trim(Mid(M_Amount_US, 4)) + ".00"
            End If
            Hunds = Mid(M_Amount_US, 9, 3)
            Thous = Mid(M_Amount_US, 7, 2)
            Lakhs = Mid(M_Amount_US, 5, 2)
            Crores = Mid(M_Amount_US, 1, 4)
            Decs = Mid(M_Amount_US, 13, 2)
            AmountInWords = ""
            If Val(Crores) <> 0 Then
                AmountInWords = AmountInWords + Trim(Number_to_Text(Crores)) + " CRORE "
            End If
            If Val(Lakhs) <> 0 Then
                AmountInWords = AmountInWords + Trim(Number_to_Text(Lakhs)) + " LAKH "
            End If
            If Val(Thous) <> 0 Then
                AmountInWords = AmountInWords + Trim(Number_to_Text(Thous)) + " THOUSAND "
            End If
            If Val(Hunds) <> 0 Then
                AmountInWords = AmountInWords + Trim(Number_to_Text(Hunds))
            End If
            AmountInWords = Trim(Maincur_code) & " " + AmountInWords
            AmountInWords = SentenceCase(AmountInWords)
            If Val(Decs) <> 0 Then
                AmountInWords = AmountInWords & " " & SentenceCase(separationChar) & " " & _
                SentenceCase(Trim(Number_to_Text(Decs))) & " " & Trim(FractCur_code)
                'AmountInWords = AmountInWords & " " & SentenceCase(separationChar) & " " & _
                'Trim(FractCur_code) & " " & SentenceCase(Trim(Number_to_Text(Decs)))
            End If
            AmountInWords = AmountInWords & " Only "
        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Function
#End Region

#Region "SentenceCase"
    Public Function SentenceCase(ByVal Sentence As String)
        Try
            Dim WordDelimiter As String
            Dim i As Integer
            Dim character As String
            Dim LastWasDelimiterFlag As Boolean
            Dim SentenceArray
            Dim NewSentence As String
            WordDelimiter = " ."
            NewSentence = ""
            LastWasDelimiterFlag = True
            For i = 1 To Len(Sentence)
                character = Mid(Sentence, i, 1)
                If LastWasDelimiterFlag Then
                    NewSentence = NewSentence & UCase(character)
                Else
                    NewSentence = NewSentence & LCase(character)
                End If
                If InStr(WordDelimiter, character) > 0 Then
                    LastWasDelimiterFlag = True
                Else
                    LastWasDelimiterFlag = False
                End If
            Next
            SentenceCase = NewSentence

        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Function
#End Region

#Region "Connect to company"
    Public Function sysStartUp() As Boolean

        Dim objSAPDB As SAPbobsCOM.Company
        Dim intCompanyNumber As Integer = 0
        Dim objSAPDBTarget(4) As SAPbobsCOM.Company
        Dim objAsseTrackerDB As SqlClient.SqlConnection
        Dim blnDateCheckDone As Boolean
        Dim oSalesPerson As SAPbobsCOM.IDocuments
        Dim objDBCon As New SqlClient.SqlConnection
        Dim a As Integer
        If objDBCon.State <> ConnectionState.Open Then
            Dim strConnCommon As String
            'objDBCon.ConnectionString = objSysEnv.strConnectionString '& ";Initial Catalog=" & objSysEnv.strControlDB
            strConnCommon = "User ID=sa;Server=sap-server;Pwd=Sbs2003;Initial Catalog=Wintech Test;Integrated Security=True"
            objDBCon.ConnectionString = strConnCommon
            objDBCon.Open()
        End If
        If objSAPDB Is Nothing Then
            Try
                objSAPDB = New SAPbobsCOM.Company
                objSAPDB.CompanyDB = "Wintech Test"
                objSAPDB.UserName = "manager"
                objSAPDB.Password = "manager"
                objSAPDB.DbUserName = "sa"
                objSAPDB.DbPassword = "Sbs2003"
                objSAPDB.Server = "SAP-SERVER"
                objSAPDB.language = SAPbobsCOM.BoSuppLangs.ln_English
                MsgBox(objDBCon.ConnectionString)
                a = objSAPDB.Connect()

                Dim lErrCode As Integer = 0, sErrMsg As String = ""
                objSAPDB.GetLastError(lErrCode, sErrMsg)

                If sErrMsg <> vbNullString Then
                    Return False
                End If
            Catch ex As Exception
                Return False
            End Try
        End If
        'oSalesPerson = objSAPDB.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oOrders)
        'oSalesPerson.CardCode = "WC00001"
        'oSalesPerson.Lines.ItemCode = "OA0001"
        'oSalesPerson.Lines.WarehouseCode = "01"
        'oSalesPerson.Add()
        'If oSalesPerson.Add <> 0 Then
        '    MsgBox(oApplication.Company.GetLastErrorDescription)
        'End If
        ''oSalesPerson.Lines.Add()
        'If blnDateCheckDone = False Then
        '    blnDateCheckDone = True
        'End If
        'Return True
    End Function
#End Region

#Region "Fill Combo"
    Public Sub FillCombo(ByVal Formuid As String, ByVal combouid As String, ByVal SQL As String, ByVal ComboValue As String, ByVal ComboDescription As String, ByVal DisplayDisc As Boolean, ByVal AddBlankVal As Boolean, ByVal AddValALL As Boolean, ByVal AddSelectVal As Boolean)
        Try
            Dim RS As SAPbobsCOM.Recordset
            Dim oCombo As SAPbouiCOM.ComboBox
            Dim oItem As SAPbouiCOM.Item
            Dim oForm As SAPbouiCOM.Form
            Dim i As Integer
            oForm = oApplication.SBO_Application.Forms.Item(Formuid)
            Me.ExecuteSQL(RS, SQL)
            oCombo = oForm.Items.Item("" & combouid & "").Specific
            If AddBlankVal = True Then
                oCombo.ValidValues.Add("", "")
            End If
            If RS.RecordCount > 0 Then
                For i = 0 To RS.RecordCount - 1
                    oCombo.ValidValues.Add(RS.Fields.Item("" & ComboValue & "").Value, RS.Fields.Item("" & ComboDescription & "").Value)
                    RS.MoveNext()
                Next
            End If
            If AddValALL = True Then
                oCombo.ValidValues.Add("ALL", "ALL")
                oCombo.Select("ALL", SAPbouiCOM.BoSearchKey.psk_ByValue)
            End If
            If AddSelectVal = True Then
                oCombo.ValidValues.Add("-Select-", "-Select-")
                oCombo.Select("-Select-", SAPbouiCOM.BoSearchKey.psk_ByValue)
            End If
            oItem = oForm.Items.Item("" & combouid & "")
            oItem.DisplayDesc = DisplayDisc
        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
#End Region

#Region "Filters"
    Public Sub SetFilters()
        Try
            '// Create a new EventFilters object
            oFilters = New SAPbouiCOM.EventFilters
            '###################### Form Load Event ###########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_LOAD)
           oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)
            '##################################################################

            '###################### Item Press Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED)
            oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)
            '##################################################################

            '###################### Combo Select Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_COMBO_SELECT)
            oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)

            '##################################################################

            '###################### Form Close Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_CLOSE)
            oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)
            oFilter.AddEx("CMLogs") '@@@@@ NACHA Import (User Form)

            '##################################################################

            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE)


            '######################Form Data Load Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)

            '##################################################################

            '###################### CFL Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST)
            oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)
            '##################################################################

            '###################### Key Down Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_KEY_DOWN)
            oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)

            
            '######################Lost Focus Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_LOST_FOCUS)
            
            '###################### Validate Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_VALIDATE)

            
            ' ###################### Menu Click Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_MENU_CLICK)
            oFilter.AddEx("BankExtract") '@@@@@ NACHA Import (User Form)
            '##################################################################


            ' ###################### Click Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_CLICK)
            
            '###################### Menu Click Event ##########################
            oFilter = oFilters.Add(SAPbouiCOM.BoEventTypes.et_FORM_ACTIVATE)
            'oFilter.AddEx("UDF") '@@@@@ NACHA Import (User Form)
            '##################################################################


            oApplication.SBO_Application.SetFilter(oFilters)
        Catch ex As Exception
            oApplication.Utilities.Message(ex.Message, SAPbouiCOM.BoStatusBarMessageType.smt_Error)
        End Try
    End Sub
#End Region

#Region "Table Creation"

    Private Sub CreateTable(ByVal txttablename As String, ByVal txtTableDescription As String, ByVal txtTabletype As Integer)
        NCMTables = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables)
        If NCMTables.GetByKey(CStr(txttablename)) Then
            NCMTables = Nothing
        Else
            NCMTables.TableName = txttablename
            NCMTables.TableDescription = txtTableDescription
            NCMTables.TableType = txtTabletype
            Dim x As Integer = NCMTables.Add()
            If x <> 0 Then
                Dim ErrCode As Long
                Dim ErrMsg As String

                oApplication.Company.GetLastError(ErrCode, ErrMsg)
                oApplication.SBO_Application.StatusBar.SetText("Table creation failed due to " & ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            Else
                oApplication.SBO_Application.StatusBar.SetText("Table Created", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            End If

        End If
        NCMTables = Nothing
        GC.Collect()
    End Sub

    Private Sub CreateField(ByVal txttablename As String, ByVal txtFieldname As String, ByVal txtFieldDescription As String, ByVal type As Integer, ByVal subtype As Integer, ByVal Size As Integer, Optional ByVal Mandatory As SAPbobsCOM.BoYesNoEnum = SAPbobsCOM.BoYesNoEnum.tNO, Optional ByVal ValidValue As Integer = 0)

        NCMFields = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields)
        Try
            NCMFields.TableName = txttablename
            NCMFields.Name = txtFieldname
            NCMFields.Description = txtFieldDescription
            NCMFields.Type = type
            NCMFields.Mandatory = Mandatory

            If type = 2 Then
                NCMFields.EditSize = Size
            End If

            If type = 0 Then
                NCMFields.EditSize = Size
            End If

            If type = 4 Then
                NCMFields.SubType = subtype
            End If

            If type = 3 Then
                NCMFields.SubType = subtype
            End If

            If ValidValue = 1 Then
                NCMFields.ValidValues.Value = "Round Up"
                NCMFields.ValidValues.Description = "Round Up"
                NCMFields.ValidValues.Add()
                NCMFields.ValidValues.Value = "Round Down"
                NCMFields.ValidValues.Description = "Round Down"
                NCMFields.ValidValues.Add()
                NCMFields.ValidValues.Value = "None"
                NCMFields.ValidValues.Description = "None"
                NCMFields.ValidValues.Add()
                NCMFields.DefaultValue = "None"

            End If

            If ValidValue = 2 Then
                NCMFields.ValidValues.Value = "N"
                NCMFields.ValidValues.Description = "NO"
                NCMFields.ValidValues.Add()
                NCMFields.ValidValues.Value = "Y"
                NCMFields.ValidValues.Description = "YES"
                NCMFields.ValidValues.Add()
                NCMFields.DefaultValue = "N"
            End If

            If ValidValue = 4 Then
                NCMFields.LinkedTable = "BLE_MRPT"
            End If

            Dim x As Integer
            x = NCMFields.Add()

            Dim ErrCode As Long
            Dim ErrMsg As String

            If x <> 0 Then
               
                oApplication.Company.GetLastError(ErrCode, ErrMsg)
                If ErrCode <> -2035 And ErrCode <> -5002 And ErrCode <> -1120 Then
                    oApplication.SBO_Application.StatusBar.SetText("Field creation failed due to " & ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                End If
            Else
                oApplication.SBO_Application.StatusBar.SetText("Field Created", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
            End If



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        NCMFields = Nothing
        GC.Collect()
    End Sub

    Public Sub CallCreateTable()

        CreateField("OVPM", "BOSBEDTM", "Bank Extract Date Time", 0, 0, 50)


        '************************MPS Table**************************
        CreateTable("BOSBECONFIG", "Bank Extract Conf", 1)
        'CreateField("BOSBECONFIG", "RefDt", "Reference Date", 3, 0, 10)
        CreateField("BOSBECONFIG", "ACTIVE", "ACTIVE", 0, 0, 1, SAPbobsCOM.BoYesNoEnum.tNO, 2)
        CreateField("BOSBECONFIG", "OUTDIR", "OUTDIR", 0, 0, 150)
        CreateField("BOSBECONFIG", "ARCHDIR", "ARCHDIR", 0, 0, 150)
        CreateField("BOSBECONFIG", "FILENAME", "FILENAME", 0, 0, 100)
        CreateField("BOSBECONFIG", "EXT", "EXT", 0, 0, 10)
        'CreateField("BOSBECONFIG", "FILENAME", "FILENAME", 0, 0, 100)
        CreateField("BOSBECONFIG", "NEWVIEW", "NEWVIEW", 0, 0, 50)
        CreateField("BOSBECONFIG", "HISTVIEW", "HISTVIEW", 0, 0, 50)
        CreateField("BOSBECONFIG", "EXTLOGIC", "EXTLOGIC", 0, 0, 50)
        CreateField("BOSBECONFIG", "VALIDVIEW", "VALIDVIEW", 0, 0, 50)

        CreateTable("BOSBELOG", "Bank Extract Log", 0)
        'CreateField("BOSBELOG", "RefDt", "Reference Date", 3, 0, 10)
        CreateField("BOSBELOG", "ACTIVE", "ACTIVE", 0, 0, 1, SAPbobsCOM.BoYesNoEnum.tNO, 2)
        CreateField("BOSBELOG", "ProcID", "ProcID", 0, 0, 20)
        CreateField("BOSBELOG", "ProcDTM", "ProcDTM", 3, 0, 10)
        CreateField("BOSBELOG", "ExportCode", "ExportCode", 0, 0, 20)
        CreateField("BOSBELOG", "UserID", "UserID", 0, 0, 20)
        CreateField("BOSBELOG", "BankAcct", "BankAcct", 0, 0, 15)
        CreateField("BOSBELOG", "OUTDIR", "OUTDIR", 0, 0, 150)
        CreateField("BOSBELOG", "ARCHDIR", "ARCHDIR", 0, 0, 150)
        CreateField("BOSBELOG", "FILENAME", "FILENAME", 0, 0, 100)
        CreateField("BOSBELOG", "PayPrcd", "Payments#", 1, 0, 254)


    End Sub

    Private Sub AddUDO(ByVal strUDO As String, ByVal strDesc As String, ByVal strTable As String, _
                             Optional ByVal sFind1 As String = "", Optional ByVal sFind2 As String = "", Optional ByVal sFind3 As String = "", _
                                     Optional ByVal strChildTbl1 As String = "", Optional ByVal strChildTbl2 As String = "", Optional ByVal nObjectType As SAPbobsCOM.BoUDOObjType = SAPbobsCOM.BoUDOObjType.boud_Document, Optional ByVal CanLog As Boolean = False)

        Dim oUserObjectMD As SAPbobsCOM.UserObjectsMD
        Try
            oUserObjectMD = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD)
            If oUserObjectMD.GetByKey(strUDO) = 0 Then
                oUserObjectMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tNO
                oUserObjectMD.CanClose = SAPbobsCOM.BoYesNoEnum.tNO
                oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES
                oUserObjectMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES
                oUserObjectMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES

                If sFind1 <> "" Then
                    oUserObjectMD.FindColumns.ColumnAlias = sFind1
                    oUserObjectMD.FindColumns.Add()
                End If
                If sFind2 <> "" Then
                    oUserObjectMD.FindColumns.SetCurrentLine(1)
                    oUserObjectMD.FindColumns.ColumnAlias = sFind2
                    oUserObjectMD.FindColumns.Add()
                End If
                If sFind3 <> "" Then
                    oUserObjectMD.FindColumns.SetCurrentLine(2)
                    oUserObjectMD.FindColumns.ColumnAlias = sFind3
                    oUserObjectMD.FindColumns.Add()
                End If
                If CanLog = True Then
                    oUserObjectMD.CanLog = SAPbobsCOM.BoYesNoEnum.tYES
                ElseIf CanLog = False Then
                    oUserObjectMD.CanLog = SAPbobsCOM.BoYesNoEnum.tNO
                End If
                'oUserObjectMD.LogTableName = ""
                oUserObjectMD.CanYearTransfer = SAPbobsCOM.BoYesNoEnum.tNO
                oUserObjectMD.ExtensionName = ""

                If strChildTbl1 <> "" Then
                    oUserObjectMD.ChildTables.TableName = strChildTbl1
                    oUserObjectMD.ChildTables.Add()
                End If

                If strChildTbl2 <> "" Then
                    oUserObjectMD.ChildTables.TableName = strChildTbl2
                    oUserObjectMD.ChildTables.Add()
                End If

                oUserObjectMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tNO
                oUserObjectMD.Code = strUDO
                oUserObjectMD.Name = strDesc
                oUserObjectMD.ObjectType = nObjectType
                oUserObjectMD.TableName = strTable
                oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES
                Dim ret As Integer = oUserObjectMD.Add()
                'If ret <> 0 Then
                '    Throw New Exception(oApplication.Company.GetLastErrorDescription)
                'End If
                If ret <> 0 Then
                    Dim ErrCode As Long
                    Dim ErrMsg As String
                    oApplication.Company.GetLastError(ErrCode, ErrMsg)
                    oApplication.SBO_Application.StatusBar.SetText("UDO creation failed due to " & ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                Else
                    oApplication.SBO_Application.StatusBar.SetText("UDO Created", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
                End If

                If oUserObjectMD.GetByKey("BOS_BECONF") = True Then
                    oUserObjectMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES
                    oUserObjectMD.EnableEnhancedForm = SAPbobsCOM.BoYesNoEnum.tYES
                    oUserObjectMD.MenuItem = SAPbobsCOM.BoYesNoEnum.tNO

                    oUserObjectMD.RebuildEnhancedForm = SAPbobsCOM.BoYesNoEnum.tNO
                    Dim ret1 As Integer = oUserObjectMD.Update()

                End If
            End If
        Catch ex As Exception
            'MsgBox(ex.Message)

        Finally
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oUserObjectMD)
            oUserObjectMD = Nothing
            GC.WaitForPendingFinalizers()
            GC.Collect()
        End Try

    End Sub

    Public Sub CallAddUDO()
        Try
            AddUDO("BOS_BECONF", "Bank Extract Config", "BOSBECONFIG", "U_OUTDIR", "U_ARCHDIR", "", "", "", SAPbobsCOM.BoUDOObjType.boud_MasterData, True)
            'AddUDO("NCM_BOMByProduct", "By-Product BOM UDO", "NCM_OITT", "Code", "Name", "U_FGItem", "NCM_ITT2", SAPbobsCOM.BoUDOObjType.boud_MasterData, True)
            'AddUDO("GatePass", "Gate Pass Linked to GRN", "OGPN", "DocNum", "U_DocDate", "U_DocStat", "GPN1", SAPbobsCOM.BoUDOObjType.boud_Document, True)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

#End Region

#Region "Menu Creation"
    Public Sub CreateMenu()
        Dim frmMenu As SAPbouiCOM.Form
        Dim oMenus As SAPbouiCOM.Menus
        Dim oMenuItem As SAPbouiCOM.MenuItem
        Dim MenuPara As SAPbouiCOM.MenuCreationParams
        Dim sPath As String

        Try
            sPath = oApplication.Utilities.getApplicationPath
            oMenus = oApplication.SBO_Application.Menus
            frmMenu = oApplication.SBO_Application.Forms.GetFormByTypeAndCount(169, 1)
            frmMenu.Freeze(True)
            '--------------------------------------------------------------------------------------
            'Scheme Menu Setting
            '--------------------------------------------------------------------------------------
            'oMenuItem = oApplication.SBO_Application.Menus.Item("43520")
            'oMenus = oMenuItem.SubMenus
            MenuPara = oApplication.SBO_Application.CreateObject(SAPbouiCOM.BoCreatableObjectType.cot_MenuCreationParams)
            'MenuPara.Type = SAPbouiCOM.BoMenuType.mt_POPUP
            'MenuPara.UniqueID = "MDOL"
            'MenuPara.String = "MDOL Integration"
            'MenuPara.Position = oMenuItem.SubMenus.Count + 1
            'MenuPara.Image = oApplication.Utilities.getApplicationPath & "\XML Files\AchieveOne.bmp"
            'oMenus.AddEx(MenuPara)

            oMenuItem = oApplication.SBO_Application.Menus.Item("43538")
            oMenus = oMenuItem.SubMenus
            MenuPara.Type = SAPbouiCOM.BoMenuType.mt_STRING
            MenuPara.UniqueID = "BankExtract"
            MenuPara.String = "Bank Extract"
            MenuPara.Position = 9
            oMenus.AddEx(MenuPara)

            frmMenu.Freeze(False)
            frmMenu.Update()
        Catch ex As Exception
            'Unfreeze and update the Command Center form
            oApplication.SBO_Application.StatusBar.SetText("[AddMenu]:" & ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
        Finally
            frmMenu.Freeze(False)
            frmMenu.Update()
            'oApplication.SBO_Application.StatusBar.SetText("Adama Customization connected successfully to Company - " & oApplication.Company.CompanyName, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
        End Try

    End Sub

#End Region

#Region "Create & Assign Formatted Search Queries"
    Public Sub CreateFMS()
        Dim Ret As Integer
        Dim oQueryCat As SAPbobsCOM.QueryCategories = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oQueryCategories)
        Dim oRs, oRs1 As SAPbobsCOM.Recordset
        'If oQueryCat.GetByKey(oRs.Fields.Item(0).Value) = False Then
        oQueryCat.Name = "BLE"
        oQueryCat.Permissions = "YYYYYYYYYYYYYYYYYYYY"
        oQueryCat.Add()
        'End If
        ExecuteSQL(oRs, "Select CategoryId from OQCN Where CatName='BLE'")
        Dim oQuery As SAPbobsCOM.UserQueries = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserQueries)
        ExecuteSQL(oRs1, "select intrnalkey from ouqr where qname = 'Bank Extract Log' AND qcategory=" & oRs.Fields.Item(0).Value & "")
        If oQuery.GetByKey(oRs1.Fields.Item(0).Value, oRs.Fields.Item(0).Value) = False Then
            oQuery.Query = "SELECT U_ProcID,U_ProcDTM,U_ExportCode ,U_FILENAME ,U_OUTDIR ,U_PayPrcd FROM [@BOSBELOG]"
            oQuery.QueryCategory = oRs.Fields.Item(0).Value
            oQuery.QueryDescription = "Bank Extract Log"
            Ret = oQuery.Add()
            If Ret <> 0 Then
                oApplication.SBO_Application.StatusBar.SetText("FMS Failed", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning)
            End If
        End If



    End Sub

    Public Sub AssignFMS(ByVal FormID, ByVal ItemID, ByVal ColId, ByVal QueryName)
        Dim oFormatted As SAPbobsCOM.FormattedSearches = oApplication.Company.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oFormattedSearches)
        Dim oRs As SAPbobsCOM.Recordset

        oFormatted.FormID = FormID    'for Sales Order

        oFormatted.ItemID = ItemID     'at Row Level
        'oFormatted.ColumnID = ColId
        oFormatted.FieldID = ItemID 'ItemCode
        If ColId <> "" Then
            oFormatted.ColumnID = ColId    'in ItemCode Column
        End If
        oFormatted.Action = SAPbobsCOM.BoFormattedSearchActionEnum.bofsaQuery
        ExecuteSQL(oRs, "select IntrnalKey from OUQR(nolock) Where QName = '" & QueryName & "'")

        oFormatted.QueryID = oRs.Fields.Item("IntrnalKey").Value ''"" ' oRs.GetField
        oFormatted.Refresh = SAPbobsCOM.BoYesNoEnum.tNO
        oFormatted.ForceRefresh = SAPbobsCOM.BoYesNoEnum.tNO
        oFormatted.ByField = SAPbobsCOM.BoYesNoEnum.tNO

        Dim RET As Integer = oFormatted.Add

        If RET = 0 Then ' 0 Then
            'oApplication.SBO_Application.MessageBox(oApplication.Company.GetLastErrorDescription)
        Else
            'oApplication.SBO_Application.StatusBar.SetText("FMS Added Successfully", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success)
        End If

    End Sub

#End Region

End Class



